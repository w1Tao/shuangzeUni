package cn.shuangzeit.statistics.controller;

import cn.shuangzeit.statistics.entity.Statistics;
import cn.shuangzeit.statistics.service.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/statistics")
public class StatisticsController {

    @Autowired
    private StatisticsService statisticsService;
    //获取列表
    @GetMapping
    public List<Statistics> listStatistics() {
        return statisticsService.listStatistics();
    }
    //根据id查找
    @GetMapping("/{id}")
    public ResponseEntity<Statistics> selectById(@PathVariable String id) {
        Optional<Statistics> statistics = statisticsService.selectById(id);
        return statistics.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    //新增
    @PostMapping
    public ResponseEntity<String> add(@RequestBody Statistics statistics) {
        statisticsService.addMenuNumber(statistics);
        return ResponseEntity.status(HttpStatus.OK).body("新增成功");
    }
    //更新
    @PostMapping("/{id}")
    public ResponseEntity<Void> updateById(@PathVariable String id, @RequestBody Statistics statistics) {
        Optional<Statistics> existingStatistics = statisticsService.selectById(id);
        if (existingStatistics.isPresent()) {
            statisticsService.updateById(statistics);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
