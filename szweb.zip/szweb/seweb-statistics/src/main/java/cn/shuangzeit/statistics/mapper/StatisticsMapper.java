package cn.shuangzeit.statistics.mapper;

import cn.shuangzeit.statistics.entity.Statistics;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatisticsMapper extends MongoRepository<Statistics, String> {
}