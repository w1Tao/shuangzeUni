package cn.shuangzeit.statistics.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document("statistics")
@Data
public class Statistics {

    @Id
    private String id;
    //菜单名称
    private String menuName;
    //菜单浏览数量
    private int menuNumber;

}
