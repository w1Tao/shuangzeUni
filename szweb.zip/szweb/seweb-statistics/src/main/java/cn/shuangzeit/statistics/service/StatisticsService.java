package cn.shuangzeit.statistics.service;

import cn.shuangzeit.statistics.entity.Statistics;
import cn.shuangzeit.statistics.mapper.StatisticsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

@Service
public class StatisticsService {

    @Autowired
    private StatisticsMapper statisticsMapper;

    public void addMenuNumber(Statistics statistics) {
        Optional<Statistics> existingStatistics = selectById(statistics.getId());
        if (existingStatistics.isPresent()) {
            statistics = existingStatistics.get();
            statistics.setMenuNumber(statistics.getMenuNumber() +1);
            updateById(statistics);
        } else {
            statisticsMapper.save(statistics);
        }
    }


    public void updateById(Statistics statistics) {
        statisticsMapper.save(statistics);
    }

    public List<Statistics> listStatistics() {
        return statisticsMapper.findAll();
    }

    public Optional<Statistics> selectById(String id) {
        return statisticsMapper.findById(id);
    }
}