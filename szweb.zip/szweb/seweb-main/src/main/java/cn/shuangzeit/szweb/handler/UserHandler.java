package cn.shuangzeit.szweb.handler;

import cn.shuangzeit.szweb.domain.Menu;
import cn.shuangzeit.szweb.domain.User;
import cn.shuangzeit.szweb.dto.PageSupport;
import cn.shuangzeit.szweb.repository.MenuRepository;
import cn.shuangzeit.szweb.repository.UserRepository;
import cn.shuangzeit.szweb.security.PBKDF2Encoder;
import cn.shuangzeit.szweb.security.SecurityContextHolder;
import lombok.AllArgsConstructor;
import lombok.val;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.List;
import java.util.stream.Collectors;

import static cn.shuangzeit.szweb.dto.PageSupport.DEFAULT_PAGE_SIZE;
import static cn.shuangzeit.szweb.dto.PageSupport.FIRST_PAGE_NUM;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.ServerResponse.notFound;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Component
@AllArgsConstructor
public class UserHandler {
    private final UserRepository userRepository;
    private final PBKDF2Encoder encoder;
    private final MenuRepository menuRepository;
    /**
     * 得到所有用户
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ADMIN')")
    public Mono<ServerResponse> getEntityPage(ServerRequest request) {
        val pageIndex=request.queryParam("pageIndex").map(Integer::parseInt).orElse(FIRST_PAGE_NUM);
        val pageSize=request.queryParam("pageSize").map(Integer::parseInt).orElse(DEFAULT_PAGE_SIZE);
        val name= request.queryParam("name").orElse("");
        val page= PageRequest.of(pageIndex, pageSize);
        val menuMono=menuRepository.findByName("user");
        val usersFlux=userRepository.findByNameLike(name);
        val pageContent= Mono.
                zip(menuMono,usersFlux.collectList())
                .map((Tuple2<Menu, List<User>> data) -> {
                    val title=data.getT1().getTitle();
                    val list=data.getT2();
                    return new PageSupport<>(
                            list.stream()
                                    .skip(page.getPageNumber() * page.getPageSize())
                                    .limit(page.getPageSize())
                                    .collect(Collectors.toList()),
                            page.getPageNumber(), page.getPageSize(), list.size(),title,null);
                });

        return ok().contentType(APPLICATION_JSON).body(pageContent, PageSupport.class);
    }

    /**
     * 创建用户
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ADMIN')")
    public Mono<ServerResponse> createUser(ServerRequest request) {
        val user = request.bodyToMono(User.class);
        return user.flatMap(u -> {
            u.setPassword(this.encoder.encode(u.getPassword()));
            return ok().contentType(APPLICATION_JSON)
                    .body(this.userRepository.save(u), User.class);
        });
    }

    /**
     * 更新用户信息
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ADMIN')")
    public Mono<ServerResponse> updateUser(ServerRequest request) {
        val user = request.bodyToMono(User.class);
        return user.flatMap(u ->
                this.userRepository.findById(u.getId()).flatMap(old->{
                    u.setPassword(old.getPassword());
                    return this.userRepository.save(u).then(ok().build()).switchIfEmpty(notFound().build());
                }));
    }

    /**
     * 根据id删除用户
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ADMIN')")
    public Mono<ServerResponse> deleteUserById(ServerRequest request) {
        return this.userRepository.findById(request.pathVariable("id")).flatMap(user ->
                this.userRepository.delete(user).then(ok().build()).switchIfEmpty(notFound().build()));
    }
    /**
     * 根据id获取用户
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_USER')")
    public Mono<ServerResponse> getUser(ServerRequest request) {
        return SecurityContextHolder.getCurrentUsername()
                .flatMap(username->userRepository.findByUsername(username)
                        .flatMap(user->ok().bodyValue(user)));

    }

}
