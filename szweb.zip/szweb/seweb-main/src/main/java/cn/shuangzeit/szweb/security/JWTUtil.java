package cn.shuangzeit.szweb.security;

//import cn.shuangzeit.szweb.domain.User;

import cn.shuangzeit.szweb.domain.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.io.Serializable;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


    @Component
    @Log4j2
    public class JWTUtil implements Serializable


    {
        @Value("${spring_jjwt.jjwt.secret}")
        private String secret;
        @Value("${spring_jjwt.jjwt.expiration}")
        private String expirationTime;
        public Claims getAllClaimsFromToken(String token) {
            Claims claims;
            try {
                claims= Jwts.parserBuilder()
                        .setSigningKey(Base64.getEncoder().encodeToString(secret.getBytes()))
                        .build()
                        .parseClaimsJws(token)
                        .getBody();
            }
            catch (Exception e) {
                claims=null;
                log.info("token解析错误！");
            }
            return claims;
        }
        public String getUsernameFromToken(String token) {
            return getAllClaimsFromToken(token).getSubject();
        }
        public Date getExpirationDateFromToken(String token) {
            return getAllClaimsFromToken(token).getExpiration();
        }
        public String generateToken(User user) {
            Map<String, Object> claims = new HashMap<>();
            claims.put("role", user.getAuthorities());
            Long expirationTimeLong = Long.parseLong(expirationTime); //in second
            SecretKey key = Keys.hmacShaKeyFor(secret.getBytes());
            final Date createdDate = new Date();
            final Date expirationDate = new Date(createdDate.getTime() + expirationTimeLong * 1000);
            return Jwts.builder()
                    .setClaims(claims)
                    .setSubject(user.getUsername())
                    .setIssuedAt(createdDate)
                    .setExpiration(expirationDate)
                    .signWith(key, SignatureAlgorithm.HS512)
                    .compact();
        }
        public Boolean validateToken(String token) {
            final Date expiration = getExpirationDateFromToken(token);
            return expiration.after(new Date());
        }
    }

