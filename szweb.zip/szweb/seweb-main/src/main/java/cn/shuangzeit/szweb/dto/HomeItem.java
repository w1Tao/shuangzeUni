package cn.shuangzeit.szweb.dto;

public record HomeItem<List>(
        String name,
        String type,
        String icon,
        String url,
        List items
){ }

