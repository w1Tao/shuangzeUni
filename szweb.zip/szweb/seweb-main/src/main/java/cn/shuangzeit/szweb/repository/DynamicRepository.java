package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.Dynamic;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface DynamicRepository extends ReactiveMongoRepository<Dynamic,String> {
    Flux<Dynamic> findAll();

}
