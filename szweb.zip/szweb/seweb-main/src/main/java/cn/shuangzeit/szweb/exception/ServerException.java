package cn.shuangzeit.szweb.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class ServerException extends RuntimeException {
    private int code;
    private String message;
}
