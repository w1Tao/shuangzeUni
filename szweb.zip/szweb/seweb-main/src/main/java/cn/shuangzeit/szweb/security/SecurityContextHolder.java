package cn.shuangzeit.szweb.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;

public class SecurityContextHolder {
    public static Mono<Authentication> getAuthentication(){
        return ReactiveSecurityContextHolder
                .getContext()
                .map(SecurityContext::getAuthentication).log();
    }
    public static Mono<Boolean> isAdmin(){
        return getAuthentication()
                .map(auth ->auth.getAuthorities().stream().anyMatch(authority->authority.toString().equals("ROLE_ADMIN")));
    }
    public static Mono<String> getCurrentUsername(){
        return getAuthentication()
                .map(auth ->auth.getName());
    }
}
