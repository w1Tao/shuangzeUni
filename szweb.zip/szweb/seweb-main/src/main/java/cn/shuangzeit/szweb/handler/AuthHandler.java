package cn.shuangzeit.szweb.handler;



import cn.shuangzeit.szweb.domain.User;
import cn.shuangzeit.szweb.dto.Auth;
import cn.shuangzeit.szweb.dto.Role;
import cn.shuangzeit.szweb.dto.UserDTO;
import cn.shuangzeit.szweb.exception.ServerException;
import cn.shuangzeit.szweb.repository.UserRepository;
import cn.shuangzeit.szweb.security.JWTUtil;
import cn.shuangzeit.szweb.security.PBKDF2Encoder;
import cn.shuangzeit.szweb.security.SecurityContextHolder;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import lombok.val;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromValue;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Component
@AllArgsConstructor
@Log4j2
public class AuthHandler {
    private final JWTUtil jwtUtil;
    private final PBKDF2Encoder passwordEncoder;
    private final UserRepository userRepository;
    public Mono<ServerResponse> register(ServerRequest request) {
        val userDTO = request.bodyToMono(UserDTO.class);
        Mono<User> user= userDTO.map(u -> {
            userRepository.findByUsername(u.getUsername())
                    .flatMap(result-> Mono.error(new ServerException(900,"账号已存在！")));
            userRepository.findByEmail(u.getEmail())
                    .flatMap(result->Mono.error(new ServerException(900,"电子邮箱已存在！")));
            userRepository.findByPhone(u.getMobile())
                    .flatMap(result->Mono.error(new ServerException(900,"手机号码已存在！")));
            return User.builder()
                    .name(u.getName())
                    .password(this.passwordEncoder.encode(u.getPassword()))
                    .username(u.getUsername())
                    .phone(u.getMobile())
                    .email(u.getEmail())
                    .avatar(u.getAvatar())
                    .role(Role.ROLE_ADMIN)
                    .enabled(true)
                    .createTime(LocalDateTime.parse(String.valueOf(LocalDateTime.now())))
                    .updateTime(LocalDateTime.parse(String.valueOf(LocalDateTime.now())))
                    .build();
        });
        return ok().contentType(APPLICATION_JSON)
                .body(this.userRepository.saveAll(user), User.class);
    }
    public Mono<ServerResponse> login(ServerRequest request) {
        val auth = request.bodyToMono(Auth.class);
        return auth.flatMap(au-> this.userRepository.findByUsername(au.getUsername()).flatMap(user -> {
            if (!passwordEncoder.matches(au.getPassword(), user.getPassword())) {
                return Mono.error(new ServerException(900,"密码不正确！"));
            }
            if (!user.getEnabled()){
                return Mono.error(new ServerException(900,"账号没激活，请联系管理员！"));
            }
            return ok().contentType(APPLICATION_JSON)
                    .body(fromValue(Map.of("token",jwtUtil.generateToken(user))));
        })).switchIfEmpty(Mono.error(new ServerException(900,"用户不存在！")));
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_USER')")
    public Mono<ServerResponse> getUser(ServerRequest request) {
        return SecurityContextHolder.getCurrentUsername()
                .flatMap(username->userRepository.findByUsername(username)
                        .flatMap(user->{
                            user.setPassword("");
                            return ok().bodyValue(user);
                        }));
    }
}