package cn.shuangzeit.szweb.handler;

import cn.shuangzeit.szweb.domain.Menu;
import cn.shuangzeit.szweb.domain.Overview;
import cn.shuangzeit.szweb.dto.PageSupport;
import cn.shuangzeit.szweb.exception.ServerException;
import cn.shuangzeit.szweb.repository.MenuRepository;
import cn.shuangzeit.szweb.repository.OverviewRepository;
import cn.shuangzeit.szweb.security.SecurityContextHolder;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import lombok.val;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static cn.shuangzeit.szweb.dto.PageSupport.DEFAULT_PAGE_SIZE;
import static cn.shuangzeit.szweb.dto.PageSupport.FIRST_PAGE_NUM;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.ServerResponse.notFound;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Log4j2
@Component
@AllArgsConstructor
public class OverviewHandler {
    private final OverviewRepository overviewRepository;
    private final MenuRepository menuRepository;

    public Mono<ServerResponse> getEntityPage(ServerRequest request) {
        val pageIndex = request.queryParam("pageIndex").map(Integer::parseInt).orElse(FIRST_PAGE_NUM);
        val pageSize = request.queryParam("pageSize").map(Integer::parseInt).orElse(DEFAULT_PAGE_SIZE);
        val title = request.queryParam("title").orElse("");
        val type=request.pathVariable("type");
        val menuMono = menuRepository.findByName("overview");
        val overviewsFlux = overviewRepository.findByTypeAndTitleLikeOrderByUpdateTimeDesc(type,title);
        val pageContent = Mono.
                zip(menuMono, overviewsFlux.collectList())
                .map((Tuple2<Menu, List<Overview>> data) -> {
                    val typeName=data.getT1().getTitle();
                    val name=data.getT1().getItems().stream().filter(m->m.getName().equals(type)).map(Menu::getTitle).toList().get(0);
                    val list = data.getT2();
                    return new PageSupport<>(
                            list.stream()
                                    .skip(pageIndex * pageSize)
                                    .limit(pageSize)
                                    .collect(Collectors.toList()),
                            pageIndex, pageSize, list.size(), name, typeName);
                });

        return ok().contentType(APPLICATION_JSON).body(pageContent, PageSupport.class);
    }

    /**
     * 创建学院概况
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> createOverview(ServerRequest request) {
        return Mono.zip(SecurityContextHolder.getAuthentication(), request.bodyToMono(Overview.class))
                .flatMap((Tuple2<Authentication, Overview> data) -> {
                    val auth = data.getT1();
                    val overview = data.getT2();
                    val now=LocalDateTime.now();
                    val username=auth.getName();
                    overview.setUpdateUser(username);
                    overview.setHit(0);
                    return ok().contentType(APPLICATION_JSON)
                            .body(this.overviewRepository.save(overview), Overview.class);
                });
    }
    /**
     * 更新阅读次数
     *
     * @param request
     * @return
     */
    public Mono<ServerResponse> addReading(ServerRequest request){
        val id = request.pathVariable("id");
        return overviewRepository.findById(id).flatMap(result->{
            result.setHit(result.getHit()+1);
            return overviewRepository.save(result).then(ok().bodyValue("更新成功！"));
        });

    }
    /**
     * 更新学院概况信息
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> updateOverview(ServerRequest request) {
        return Mono.zip(SecurityContextHolder.getAuthentication(), request.bodyToMono(Overview.class))
                .flatMap((Tuple2<Authentication, Overview> data) -> {
                    val auth = data.getT1();
                    val overview = data.getT2();
                    return overviewRepository.findById(overview.getId())
                            .flatMap(old -> {
                                old.setUpdateTime(LocalDateTime.now());
                                old.setUpdateUser(auth.getName());
                                old.setTitle(overview.getTitle());
                                old.setContent(overview.getContent());
                                old.setType(overview.getType());//在Notice加了type字段才不报错
                                old.setHit(overview.getHit());
                                return ok().contentType(APPLICATION_JSON)
                                        .body(this.overviewRepository.save(old), Overview.class);
                            }).switchIfEmpty(Mono.error(new ServerException(900, "您要更新的用户不存在！")));
                });
    }


    /**
     * 根据id删除学院概况
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> deleteOverviewById(ServerRequest request) {
        val id = request.pathVariable("id");
        return this.overviewRepository.existsById(id).flatMap(result -> {
            if (result) {
                return this.overviewRepository
                        .deleteById(id)
                        .then(ok().bodyValue("删除成功！"));
            } else {
                return Mono.error(new ServerException(900, "您要删除的用户不存在！"));
            }
        });
    }

    /**
     * 根据id获取学院概况
     *
     * @param request
     * @return
     */

    public Mono<ServerResponse> getOverview(ServerRequest request) {
        return overviewRepository.findById(request.pathVariable("id"))
                .flatMap(overview -> ok().contentType(APPLICATION_JSON).bodyValue(overview))
                .switchIfEmpty(notFound().build());

    }
}
