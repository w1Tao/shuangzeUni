package cn.shuangzeit.szweb.handler;

import cn.shuangzeit.szweb.domain.Menu;
import cn.shuangzeit.szweb.dto.PageSupport;
import cn.shuangzeit.szweb.dto.Role;
import cn.shuangzeit.szweb.repository.MenuRepository;
import cn.shuangzeit.szweb.security.SecurityContextHolder;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import lombok.val;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.List;
import java.util.stream.Collectors;

import static cn.shuangzeit.szweb.dto.PageSupport.DEFAULT_PAGE_SIZE;
import static cn.shuangzeit.szweb.dto.PageSupport.FIRST_PAGE_NUM;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.ServerResponse.notFound;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Log4j2
@Component
@AllArgsConstructor
public class MenuHandler {
    private final MenuRepository menuRepository;
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public Mono<ServerResponse> getEntityPage(ServerRequest request) {
        val pageIndex = request.queryParam("pageIndex").map(Integer::parseInt).orElse(FIRST_PAGE_NUM);
        val pageSize = request.queryParam("pageSize").map(Integer::parseInt).orElse(DEFAULT_PAGE_SIZE);
        val title = request.queryParam("title").orElse("");
        val page = PageRequest.of(pageIndex, pageSize);
        val menuMono=menuRepository.findByName("menu");
        val menusFlux=menuRepository.findByTitleLikeOrderByUpdateTimeDesc(title);
        val pageContent=Mono.
                zip(menuMono,menusFlux.collectList())
                .map((Tuple2<Menu, List<Menu>> data) -> {
                    val name=data.getT1().getTitle();
                    val list=data.getT2();
                    return new PageSupport<>(
                            list.stream()
                                    .skip(page.getPageNumber() * page.getPageSize())
                                    .limit(page.getPageSize())
                                    .collect(Collectors.toList()),
                            page.getPageNumber(), page.getPageSize(), list.size(),name,null);
                });

        return ok().contentType(APPLICATION_JSON).body(pageContent, PageSupport.class);
    }
    @PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_USER')")
    public Mono<ServerResponse> getBackMenus(ServerRequest request) {
        val allMenu=menuRepository.findAll();
        val resultMenu= SecurityContextHolder
                .isAdmin()
                .flatMap(admin->admin?allMenu
                        .collectList():allMenu
                        .filter(menu->menu
                                .getAuthorities()
                                .contains(Role.ROLE_USER)|menu
                                .getAuthorities()
                                .contains(Role.ROLE_PUBLIC)).collectList());

        return ok().contentType(APPLICATION_JSON).body(resultMenu,Menu.class);
    }
    public Mono<ServerResponse> getFrontMenus(ServerRequest request) {
        return  ok().contentType(APPLICATION_JSON).body(menuRepository.findAll().filter(menu -> menu.getAuthorities().contains(Role.ROLE_PUBLIC)),Menu.class);
    }
    /**
     * 创建菜单
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> createMenu(ServerRequest request) {
        return ok().contentType(APPLICATION_JSON).body(menuRepository.saveAll(request.bodyToMono(Menu.class)), Menu.class);
    }
    /**
     * 更新菜单
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> updateMenu(ServerRequest request) {
        val menu = request.bodyToMono(Menu.class);
        return ok().contentType(APPLICATION_JSON)
                .body(this.menuRepository.saveAll(menu), Menu.class);
    }
    /**
     * 根据id删除菜单
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> deleteMenuById(ServerRequest request) {
        val id = request.pathVariable("id");
        return this.menuRepository.findById(id).flatMap(menu ->
                this.menuRepository.delete(menu).then(ok().build()).switchIfEmpty(notFound().build()));
    }
    /**
     * 根据id获取菜单
     *
     * @param request
     * @return
     */
    public Mono<ServerResponse> getMenu(ServerRequest request) {
        val id = request.pathVariable("id");
        return menuRepository.findById(id)
                .flatMap(menu -> ok().contentType(APPLICATION_JSON).bodyValue(menu))
                .switchIfEmpty(notFound().build());
    }
}
