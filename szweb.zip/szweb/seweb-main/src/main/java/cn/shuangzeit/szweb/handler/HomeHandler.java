package cn.shuangzeit.szweb.handler;

import cn.shuangzeit.szweb.domain.*;
import cn.shuangzeit.szweb.dto.HomeItem;
import cn.shuangzeit.szweb.repository.*;
import lombok.AllArgsConstructor;
import lombok.val;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Component
@AllArgsConstructor
public class HomeHandler {
    private TeachingResearchRepository teachingResearchRepository;
    private DynamicRepository dynamicRepository;
    private GraduateRepository graduateRepository;
    private NoticeRepository noticeRepository;
    private CarouselRepository carouselRepository;

    public Mono<ServerResponse> homeList(ServerRequest request) {
        val result = Mono.zip(getCarouselList(), getDynamicList(), getGraduateList(), getTeachingList(), getNoticeList())
                .map(data -> {
                    val data1 = data.getT1();
                    val data2 = data.getT2();
                    val data3 = data.getT3();
                    val data4 = data.getT4();
                    val data5 = data.getT5();
                    List<HomeItem> items = new ArrayList<>();
                    List<HomeItem> subItems = new ArrayList<>();

                    HomeItem temp = new HomeItem("通知通告", null, "cast", "notice", data5);
                    subItems.add(temp);
                    temp = new HomeItem("学院动态", null, "cast", "dynamic", data2);
                    subItems.add(temp);
                    temp = new HomeItem("教学活动", "teaching", "cast", "teachingResearch", data4);
                    subItems.add(temp);
                    temp = new HomeItem("null", null, "null", "graduate", subItems);
                    items.add(temp);
                    temp = new HomeItem("校友风采", null, "movie_filter", "graduate", data3);
                    items.add(temp);
                    temp = new HomeItem("图片新闻", null, "photo_library", "carousel", data1);
                    items.add(temp);

                    return items;
                });
        return ok().contentType(APPLICATION_JSON).body(result, ArrayList.class);
    }

    private Mono<List<TeacherResearch>> getTeachingList() {
        return teachingResearchRepository
                .findByTypeAndTitleLikeOrderByUpdateTimeDesc("teaching", "")
                .take(10).collectList();
    }

    private Mono<List<Dynamic>> getDynamicList() {
        return dynamicRepository
                .findAll(Sort.by(Sort.Direction.ASC, "updateTime"))
                .take(10).collectList();
    }

    private Mono<List<Notice>> getNoticeList() {
        return noticeRepository
                .findAll(Sort.by(Sort.Direction.ASC, "updateTime"))
                .take(10).collectList();
    }

    private Mono<List<Graduate>> getGraduateList() {
        return graduateRepository
                .findAll(Sort.by(Sort.Direction.ASC, "updateTime"))
                .take(3).collectList();
    }

    private Mono<List<Carousel>> getCarouselList() {
        return carouselRepository
                .findAll(Sort.by(Sort.Direction.ASC, "updateTime"))
                .take(3).collectList();
    }
}