package cn.shuangzeit.szweb.router;

import cn.shuangzeit.szweb.handler.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

@Configuration
public class Routers {
    @Bean
    RouterFunction<ServerResponse> noticeRouters(NoticeHandler handler) {
        return RouterFunctions.route()
                .GET("/public/notices", handler::getEntityPage)
                .GET("/public/notice/{id}", handler::addReading)
                .POST("/notice", handler::createNotice)
                .PUT("/notice", handler::updateNotice)
                .DELETE("/notice/{id}", handler::deleteNoticeById)
                .build();
    }

    @Bean
    RouterFunction<ServerResponse> authRouters(AuthHandler handler) {
        return RouterFunctions.route()
                .POST("/auth/register", handler::register)
                .POST("/auth/login", handler::login)
                .GET("/auth/info", handler::getUser)

                .build();

    }

    @Bean
    RouterFunction<ServerResponse> userRouters(UserHandler handler) {
        return RouterFunctions.route()
                .GET("/users", handler::getEntityPage)
                .POST("/user", handler::createUser)
                .PUT("/user", handler::updateUser)
                .DELETE("/user/{id}", handler::deleteUserById)
                .build();
    }

    @Bean
    RouterFunction<ServerResponse> menuRouters(MenuHandler handler) {
        return RouterFunctions.route()
                .GET("/menus", handler::getEntityPage)
                .POST("/menu", handler::createMenu)
                .PUT("/menu", handler::updateMenu)
                .DELETE("/menu/{id}", handler::deleteMenuById)
                .build();
    }

    @Bean
    RouterFunction<ServerResponse> overviewRouters(OverviewHandler handler) {
        return RouterFunctions.route()
                .GET("/public/overview/{type}", handler::getEntityPage)
                .GET("/public/overview/{id}", handler::addReading)
                .POST("/overview/{type}", handler::createOverview)
                .PUT("/overview", handler::updateOverview)
                .DELETE("/overview/{id}", handler::deleteOverviewById)
                .build();
    }

    @Bean
    RouterFunction<ServerResponse> homeRouters(HomeHandler handler) {
        return RouterFunctions.route()
                .GET("/public/home", handler::homeList)
                .build();

    }

    @Bean
    RouterFunction<ServerResponse> fileRouters(FileHandler handler) {
        return RouterFunctions.route()
                .POST("uploadFile", handler::uploadFile)
                .GET("upload/{type}/{year}/{month}/{fileName}", handler::downloadFile)
                .build();
    }
}