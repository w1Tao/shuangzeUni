package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.TeacherResearch;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface TeachingResearchRepository extends ReactiveMongoRepository<TeacherResearch, String> {
    Flux<TeacherResearch> findByTypeAndTitleLikeOrderByUpdateTimeDesc(String type, String title);
}
