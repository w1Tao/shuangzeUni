package cn.shuangzeit.szweb.handler;

import cn.shuangzeit.szweb.exception.ServerException;
import lombok.extern.log4j.Log4j2;
import lombok.val;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyExtractors;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.springframework.web.reactive.function.server.ServerResponse.ok;


@Component
@Log4j2
public class FileHandler {
    @Value("${upload-file-server}")
    private String serverUrl;
    public static final String ROOT = "upload-dir";//上传文件的根目录--相对地址
    private static final HashMap<String, String> FILE_PATH_MAP = getFilePathMap();
    private static final HashMap<String, String> FILE_EXT_MAP = getFileExtMap();

    @PreAuthorize("hasAnyRole('ROLE_USER','ROLE_ADMIN')")
    public Mono<ServerResponse> uploadFile(ServerRequest request) {
        val type = request.queryParam("dir").orElse("image");
        System.err.println("type: "+type);
        return request
                .body(BodyExtractors.toMultipartData())
                .log("toMultipartData")
                .flatMap(part -> {
                    val map = part.toSingleValueMap();
                    val filePart = (FilePart) map.get("file");
                    val name = filePart.filename();
                    val err = filterRequest(type, name);
                    if (err != null) {
                        return Mono.error(err);
                    }
                    val now = LocalDate.now();
                    val year = Integer.toString(now.getYear());
                    val month = Integer.toString(now.getMonthValue());
                    val filePath = Paths.get(ROOT, FILE_PATH_MAP.get(type), year, month);
                    val fileName = UUID.randomUUID().toString() + getFileExtension(name);
                    val file = Paths.get(filePath.toString(), fileName).toFile();
                    try {
                        if (!Files.exists(filePath)) {
                            Files.createDirectories(filePath);
                        }
                        file.createNewFile();

                    } catch (IOException e) {
                        e.printStackTrace();
                        return Mono.error(new ServerException(1, "上传文件失败，原因：" + e.getMessage()));
                    }
                    Map url=new HashMap();
                    url.put("url",serverUrl + "/upload/" + type + "/" + year + "/" + month + "/" + fileName);
                    return filePart
                            .transferTo(file)
                            .log("文件创建成功！")
                            .then(ok().bodyValue(Map.of("errno", 0,"data",url)));
                });
    }

    public Mono<ServerResponse> downloadFile(ServerRequest request) {
        val type = request.pathVariable("type");
        val year = request.pathVariable("year");
        val month = request.pathVariable("month");
        val fileName = request.pathVariable("fileName");
        val path = Paths.get(ROOT, type, year, month, fileName);
        Mono<InputStream> fileMono = Mono.empty();
        try {
            fileMono = Mono.just(Files.newInputStream(path));
        } catch (IOException e) {
            log.error("文件：" + e.getMessage() + "不存在！");
            return Mono.error(new ServerException(1, "文件：" + e.getMessage() + "不存在！"));
        }
        return fileMono.flatMap(inputStream -> ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .bodyValue(new InputStreamResource(inputStream)));

    }

    private ServerException filterRequest(String type, String fileName) {
        if (!FILE_EXT_MAP.containsKey(type)) {
            return new ServerException(1, "文件类型不正确!");
        }
        String fileExt = getFileExtension(fileName).replace(".", "");
        if (!Arrays.asList(FILE_EXT_MAP.get(type).split(",")).contains(fileExt)) {
            String msg = "上传文件扩展名" + fileExt + "是不允许的扩展名,目前只允许" + FILE_EXT_MAP.get(type) + "格式";
            return new ServerException(1, msg);
        }
        //
        return null;
    }

    private String getFileExtension(String fileName) {
        String fileExtension = fileName.indexOf(".") != -1 ? fileName.substring(fileName.lastIndexOf("."), fileName.length()) : "";
        fileExtension = fileExtension.toLowerCase();
        return fileExtension;
    }

    private static HashMap<String, String> getFileExtMap() {
        // 定义允许上传的文件扩展名
        HashMap<String, String> extMap = new HashMap<String, String>();
        extMap.put("image", "gif,jpg,jpeg,png,bmp");
        extMap.put("avatar", "gif,jpg,jpeg,png,bmp");
        extMap.put("media", "swf,flv,mp3,wav,wma,wmv,mid,avi,mpg,asf,rm,rmvb");
        extMap.put("file", "doc,docx,xls,xlsx,ppt,pptx,zip,rar,pdf");
        return extMap;
    }

    private static HashMap<String, String> getFilePathMap() {
        // 定义允许上传的文件保存路径
        HashMap<String, String> pathMap = new HashMap<String, String>();
        pathMap.put("image", "image");
        pathMap.put("avatar", "avatar");
        pathMap.put("file", "file");
        pathMap.put("media", "media");
        return pathMap;
    }
}
