package cn.shuangzeit.szweb.dto;

public enum Role {
    ROLE_USER, ROLE_ADMIN,ROLE_PUBLIC
}