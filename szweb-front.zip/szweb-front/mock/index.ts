import type { MockMethod } from 'vite-plugin-mock'

const userData = [

    {

        username: 'admin',

        password: '12345678'

    },

    {

        username: 'test',

        password: 'test'

    }

]

const homeData= [

    {

        "name": null,

        "type": null,

        "icon": null,

        "url": null,

        "items": [

            {

                "name": "通知通告",

                "type": null,

                "icon": "cast",

                "url": "notice",

                "items": [

                    {

                        "title": "title1",

                        "updateTime": "2022-11-24T07:58:39.094",

                        "updateUser": "admin",

                        "id": "637d6cd3200648766e852cc9",

                        "content": "<p>content1</p>",

                        "hit": 0

                    },

                    {

                        "title": "title2",

                        "updateTime": "2022-11-24T08:39:14.874",

                        "updateUser": "admin",

                        "id": "637d6cef200648766e852cca",

                        "content": "<p>content2</p>",

                        "hit": 0

                    }

                ]

            },

            {

                "name": "学院动态",

                "type": null,

                "icon": "cast",

                "url": "dynamic",

                "items": [

                    {

                        "title": "title222",

                        "updateTime": "2022-11-23T07:30:02.231",

                        "updateUser": "admin",

                        "id": "63797f4496aa6632206eb99e",

                        "content": "<p>content1</p>",

                        "hit": 0

                    }

                ]

            },

            {

                "name": "教学活动",

                "type": "teaching",

                "icon": "cast",

                "url": "teachingResearch",

                "items": [

                    {

                        "title": "title111",

                        "updateTime": "2022-11-16T05:55:13.467",

                        "updateUser": "admin",

                        "id": "63731ecce4dacd61a8c859d4",

                        "content": "<p>content</p>",

                        "type": "teaching",

                        "hit": 0

                    }

                ]

            }

        ]

    },

    {

        "name": "校友风采",

        "type": null,

        "icon": "movie_filter",

        "url": "graduate",

        "items": [

            {

                "title": "优秀校友段誉",

                "updateTime": "2022-11-24T06:03:28.277",

                "updateUser": "admin",

                "id": "637e98b097f68f7f3d729325",

                "imgUrl": "/images/xydy.jpg",

                "content": "<p>优秀校友段誉</p>",

                "hit": 0

            },

            {

                "title": "优秀校友杨过",

                "updateTime": "2022-11-24T06:04:03.472",

                "updateUser": "admin",

                "id": "637e98d397f68f7f3d729326",

                "imgUrl": "/images/xyyg.jpg",

                "content": "<p>优秀校友杨过</p>",

                "hit": 0

            },

            {

                "title": "优秀校友张无忌",

                "updateTime": "2022-11-24T07:11:17.029",

                "updateUser": "admin",

                "id": "637ea895c0767a0b877c9114",

                "imgUrl": "/images/xyzwj.jpg",

                "content": "<p>优秀校友张无忌</p>",

                "hit": 0

            }

        ]

    },

    {

        "name": "图片新闻",

        "type": null,

        "icon": "photo_library",

        "url": "carousel",

        "items": [

            {

                "title": "test1",

                "updateTime": "2022-11-24T05:46:53.391",

                "updateUser": "admin",

                "id": "637e943397f68f7f3d729322",

                "imgUrl": "/images/tpxw1.jpg",

                "content": "<p>test</p>",

                "hit": 0

            },

            {

                "title": "test2",

                "updateTime": "2022-11-24T05:47:30.33",

                "updateUser": "admin",

                "id": "637e94f297f68f7f3d729323",

                "imgUrl": "/images/tpxw2.jpg",

                "content": "<p>test2</p>",

                "hit": 0

            },

            {

                "title": "test3",

                "updateTime": "2022-11-24T05:47:56.888",

                "updateUser": "admin",

                "id": "637e950c97f68f7f3d729324",

                "imgUrl": "/images/tpxw3.jpg",

                "content": "<p>test3</p>",

                "hit": 0

            }

        ]

    }

]

const menuData = [

    {

        "title": "学院概况",

        "updateTime": "2022-11-23T07:59:21.55",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff57",

        "name": "overview",

        "icon": "dvr",

        "parent": null,

        "items": [

            {

                "title": "学院简介",

                "updateTime": "2022-11-23T07:59:21.55",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff54",

                "name": "introduction",

                "icon": "assignment",

                "parent": "学院概况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.55"

            },

            {

                "title": "师资队伍",

                "updateTime": "2022-11-23T07:59:21.55",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff55",

                "name": "teacher",

                "icon": "assignment_ind",

                "parent": "学院概况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.55"

            },

            {

                "title": "专业设置",

                "updateTime": "2022-11-23T07:59:21.55",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff56",

                "name": "specialty",

                "icon": "perm_data_setting",

                "parent": "学院概况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.55"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.55"

    },

    {

        "title": "教研工作",

        "updateTime": "2022-11-23T07:59:21.553",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff5a",

        "name": "teachingResearch",

        "icon": "school",

        "parent": null,

        "items": [

            {

                "title": "教学活动",

                "updateTime": "2022-11-23T07:59:21.553",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff58",

                "name": "teaching",

                "icon": "local_library",

                "parent": "教研工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.553"

            },

            {

                "title": "科研情况",

                "updateTime": "2022-11-23T07:59:21.553",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff59",

                "name": "research",

                "icon": "list_alt",

                "parent": "教研工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.553"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.553"

    },

    {

        "title": "团学工作",

        "updateTime": "2022-11-23T07:59:21.556",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff5d",

        "name": "memberStudent",

        "icon": "recent_actors",

        "parent": null,

        "items": [

            {

                "title": "团学活动",

                "updateTime": "2022-11-23T07:59:21.556",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5b",

                "name": "member",

                "icon": "outlined_flag",

                "parent": "团学工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.556"

            },

            {

                "title": "优秀学子",

                "updateTime": "2022-11-23T07:59:21.556",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5c",

                "name": "student",

                "icon": "how_to_reg",

                "parent": "团学工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.556"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.556"

    },

    {

        "title": "就业情况",

        "updateTime": "2022-11-23T07:59:21.559",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff61",

        "name": "employment",

        "icon": "card_travel",

        "parent": null,

        "items": [

            {

                "title": "校内实训",

                "updateTime": "2022-11-23T07:59:21.559",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5e",

                "name": "training",

                "icon": "account_balance",

                "parent": "就业情况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.559"

            },

            {

                "title": "定岗实习",

                "updateTime": "2022-11-23T07:59:21.559",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5f",

                "name": "practice",

                "icon": "event",

                "parent": "就业情况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.559"

            },

            {

                "title": "就业信息",

                "updateTime": "2022-11-23T07:59:21.559",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff60",

                "name": "employmentInfor",

                "icon": "library_books",

                "parent": "就业情况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.559"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.559"

    },

    {

        "title": "校企合作",

        "updateTime": "2022-11-23T07:59:21.561",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff64",

        "name": "collaboration",

        "icon": "business",

        "parent": null,

        "items": [

            {

                "title": "企业情况",

                "updateTime": "2022-11-23T07:59:21.561",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff62",

                "name": "enterprise",

                "icon": "ballot",

                "parent": "校企合作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.561"

            },

            {

                "title": "合作动态",

                "updateTime": "2022-11-23T07:59:21.561",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff63",

                "name": "cooperationInfor",

                "icon": "cached",

                "parent": "校企合作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.561"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.561"

    },

    {

        "title": "下载中心",

        "updateTime": "2022-11-23T07:59:21.564",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff65",

        "name": "download",

        "icon": "save_alt",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.564"

    }

]

const tokenData={

    "token": "eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE2ODEzMzg2MDksImV4cCI6MTY4MTM2NzQwOX0.1czzfrarDy2RaPBKPDYFixgJxPhMpYOvcw69DcERlsC0ynZkRBarwd2cBBkCSLdQDJk23doBc4CNbz7b9Q1-fw"

}

const adminMenuData=[

    {

        "title": "学院概况",

        "updateTime": "2022-11-23T07:59:21.55",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff57",

        "name": "overview",

        "icon": "dvr",

        "parent": null,

        "items": [

            {

                "title": "学院简介",

                "updateTime": "2022-11-23T07:59:21.55",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff54",

                "name": "introduction",

                "icon": "assignment",

                "parent": "学院概况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.55"

            },

            {

                "title": "师资队伍",

                "updateTime": "2022-11-23T07:59:21.55",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff55",

                "name": "teacher",

                "icon": "assignment_ind",

                "parent": "学院概况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.55"

            },

            {

                "title": "专业设置",

                "updateTime": "2022-11-23T07:59:21.55",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff56",

                "name": "specialty",

                "icon": "perm_data_setting",

                "parent": "学院概况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.55"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.55"

    },

    {

        "title": "教研工作",

        "updateTime": "2022-11-23T07:59:21.553",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff5a",

        "name": "teachingResearch",

        "icon": "school",

        "parent": null,

        "items": [

            {

                "title": "教学活动",

                "updateTime": "2022-11-23T07:59:21.553",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff58",

                "name": "teaching",

                "icon": "local_library",

                "parent": "教研工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.553"

            },

            {

                "title": "科研情况",

                "updateTime": "2022-11-23T07:59:21.553",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff59",

                "name": "research",

                "icon": "list_alt",

                "parent": "教研工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.553"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.553"

    },

    {

        "title": "团学工作",

        "updateTime": "2022-11-23T07:59:21.556",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff5d",

        "name": "memberStudent",

        "icon": "recent_actors",

        "parent": null,

        "items": [

            {

                "title": "团学活动",

                "updateTime": "2022-11-23T07:59:21.556",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5b",

                "name": "member",

                "icon": "outlined_flag",

                "parent": "团学工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.556"

            },

            {

                "title": "优秀学子",

                "updateTime": "2022-11-23T07:59:21.556",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5c",

                "name": "student",

                "icon": "how_to_reg",

                "parent": "团学工作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.556"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.556"

    },

    {

        "title": "就业情况",

        "updateTime": "2022-11-23T07:59:21.559",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff61",

        "name": "employment",

        "icon": "card_travel",

        "parent": null,

        "items": [

            {

                "title": "校内实训",

                "updateTime": "2022-11-23T07:59:21.559",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5e",

                "name": "training",

                "icon": "account_balance",

                "parent": "就业情况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.559"

            },

            {

                "title": "定岗实习",

                "updateTime": "2022-11-23T07:59:21.559",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff5f",

                "name": "practice",

                "icon": "event",

                "parent": "就业情况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.559"

            },

            {

                "title": "就业信息",

                "updateTime": "2022-11-23T07:59:21.559",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff60",

                "name": "employmentInfor",

                "icon": "library_books",

                "parent": "就业情况",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.559"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.559"

    },

    {

        "title": "校企合作",

        "updateTime": "2022-11-23T07:59:21.561",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff64",

        "name": "collaboration",

        "icon": "business",

        "parent": null,

        "items": [

            {

                "title": "企业情况",

                "updateTime": "2022-11-23T07:59:21.561",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff62",

                "name": "enterprise",

                "icon": "ballot",

                "parent": "校企合作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.561"

            },

            {

                "title": "合作动态",

                "updateTime": "2022-11-23T07:59:21.561",

                "updateUser": "admin",

                "id": "637d6259f489db778d56ff63",

                "name": "cooperationInfor",

                "icon": "cached",

                "parent": "校企合作",

                "items": null,

                "authorities": [

                    "ROLE_PUBLIC"

                ],

                "createTime": "2022-11-23T07:59:21.561"

            }

        ],

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.561"

    },
    {

        "title": "用户点击数据",

        "updateTime": "2022-11-23T07:59:21.572",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff70",

        "name": "statistics",

        "icon": "perm_data_setting",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_ADMIN",

            "ROLE_USER"

        ],

        "createTime": "2022-11-23T07:59:21.572"

    },

    {

        "title": "下载中心",

        "updateTime": "2022-11-23T07:59:21.564",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff65",

        "name": "download",

        "icon": "save_alt",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_PUBLIC"

        ],

        "createTime": "2022-11-23T07:59:21.564"

    },

    {

        "title": "图片新闻",

        "updateTime": "2022-11-23T07:59:21.565",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff66",

        "name": "carousel",

        "icon": "photo_library",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_ADMIN",

            "ROLE_USER"

        ],

        "createTime": "2022-11-23T07:59:21.565"

    },

    {

        "title": "通知通告",

        "updateTime": "2022-11-23T07:59:21.567",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff67",

        "name": "notice",

        "icon": "cast",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_ADMIN",

            "ROLE_USER"

        ],

        "createTime": "2022-11-23T07:59:21.567"

    },

    {

        "title": "学院动态",

        "updateTime": "2022-11-23T07:59:21.57",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff68",

        "name": "dynamic",

        "icon": "cast_connected",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_ADMIN",

            "ROLE_USER"

        ],

        "createTime": "2022-11-23T07:59:21.57"

    },

    {

        "title": "校友风采",

        "updateTime": "2022-11-23T07:59:21.572",

        "updateUser": "admin",

        "id": "637d6259f489db778d56ff69",

        "name": "graduate",

        "icon": "movie_filter",

        "parent": null,

        "items": null,

        "authorities": [

            "ROLE_ADMIN",

            "ROLE_USER"

        ],

        "createTime": "2022-11-23T07:59:21.572"

    },
    

]

const userInfoData=[

    {

        "id": "637d5e808fcc97634ab4dba9",

        "username": "admin",

        "name": "羽过天晴",

        "email": "ygtq@haibusiness.com",

        "phone": "19999999999",

        "avatar": null,

        "createTime": "2022-11-23T07:42:56.533",

        "updateTime": "2022-11-23T07:42:56.533",

        "enabled": true,

        "authorities":[

            "ROLE_ADMIN"

        ]

    },

    {

        "id": "637d5e808fcc97634ab4dbaa",

        "username": "test",

        "name": "张三",

        "email": "zhangsan@haibusiness.com",

        "phone": "18888888888",

        "avatar": null,

        "createTime": "2022-11-23T07:42:56.591",

        "updateTime": "2022-11-23T07:42:56.591",

        "enabled": true,

        "authorities":[

            "ROLE_USER"

        ]

    }

]

const noticeData={

    "content": [

        {

            "title": "title2",

            "updateTime": "2022-11-24T08:11:26.254",

            "updateUser": "admin",

            "id": "637d6cef200648766e852cca",

            "content": "<p>content2</p><p><a data-w-e-type=\"attachment\" data-w-e-is-void data-w-e-is-inline href=\"http://localhost/upload/file/2022/11/ff05c2ec-8881-4b54-98b1-0460b0553404.docx\" download=\"新建 Microsoft Word 文档.docx\">新建 Microsoft Word 文档.docx</a></p><p><br></p><div data-w-e-type=\"video\" data-w-e-is-void>\n<video poster=\"\" controls=\"true\" width=\"auto\" height=\"auto\"><source src=\"http://localhost/upload/media/2022/11/92afef70-5895-40b7-8fff-95e0aca12e42.mp4\" type=\"video/mp4\"/></video>\n</div><p><br></p>",

            "hit": 0

        },

        {

            "title": "title1",

            "updateTime": "2022-11-24T07:58:39.094",

            "updateUser": "admin",

            "id": "637d6cd3200648766e852cc9",

            "content": "<p>content1</p><p><img src=\"http://localhost/upload/image/2022/11/45996f88-7e52-4751-82a1-58652d1d547a.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><a data-w-e-type=\"attachment\" data-w-e-is-void data-w-e-is-inline href=\"http://localhost/upload/file/2022/11/fef13001-89e6-45a8-b666-5e1402496bbc.pdf\" download=\"附件1：论文模板说明.pdf\">附件1：论文模板说明.pdf</a></p>",

            "hit": 0

        }

    ],

    "pageNumber": 10,

    "pageSize": 10,

    "totalElements": 2,

    "name": "通知通告",

    "parent": null,

    "last": true,

    "first": false,

    "totalPages": 1

}

const dynamicData={

    "content": [

        {

            "title": "title222",

            "updateTime": "2022-11-24T08:11:26.254",

            "updateUser": "admin",

            "id": "637d6cef200648766e852cca",

            "content": "<p>content2</p><p><a data-w-e-type=\"attachment\" data-w-e-is-void data-w-e-is-inline href=\"http://localhost/upload/file/2022/11/ff05c2ec-8881-4b54-98b1-0460b0553404.docx\" download=\"新建 Microsoft Word 文档.docx\">新建 Microsoft Word 文档.docx</a></p><p><br></p><div data-w-e-type=\"video\" data-w-e-is-void>\n<video poster=\"\" controls=\"true\" width=\"auto\" height=\"auto\"><source src=\"http://localhost/upload/media/2022/11/92afef70-5895-40b7-8fff-95e0aca12e42.mp4\" type=\"video/mp4\"/></video>\n</div><p><br></p>",

            "hit": 0

        },
    ],

    "pageNumber": 10,

    "pageSize": 10,

    "totalElements": 2,

    "name": "学院动态",

    "parent": null,

    "last": true,

    "first": false,

    "totalPages": 1

}

const teachingData={

    "content": [

        {

            "title": "title111",

            "updateTime": "2022-11-24T08:11:26.254",

            "updateUser": "admin",

            "id": "637d6cef200648766e852cca",

            "content": "<p>content2</p><p><a data-w-e-type=\"attachment\" data-w-e-is-void data-w-e-is-inline href=\"http://localhost/upload/file/2022/11/ff05c2ec-8881-4b54-98b1-0460b0553404.docx\" download=\"新建 Microsoft Word 文档.docx\">新建 Microsoft Word 文档.docx</a></p><p><br></p><div data-w-e-type=\"video\" data-w-e-is-void>\n<video poster=\"\" controls=\"true\" width=\"auto\" height=\"auto\"><source src=\"http://localhost/upload/media/2022/11/92afef70-5895-40b7-8fff-95e0aca12e42.mp4\" type=\"video/mp4\"/></video>\n</div><p><br></p>",

            "hit": 0

        },


    ],

    "pageNumber": 10,

    "pageSize": 10,

    "totalElements": 2,

    "name": "教学活动",

    "parent": null,

    "last": true,

    "first": false,

    "totalPages": 1

}
export default [

    {

        url: '/api/login',

        method: 'post',

        response: (data:any) => {

            const info = data.body

            let msg

            const result= userData.some(item=>{

                msg=item.username!==info.username?'用户或密码不正确！':'用户或密码不正确！'

                return item.username===info.username&&item.password===info.password

            })

           return result?tokenData:{errno:1,message:msg}

        }

  },


    {

        url: '/api/frontMenus',

        method: 'get',

        response: () => {

            return menuData

        },

    },

    {

        url: '/api/home',

        method: 'get',

        response: () => {

            return homeData

        },

    },
    {

        url: '/api/backMenus',

        method: 'get',

        response: () => {

            return adminMenuData

        },

    },

    {

        url: '/api/userinfo',

        method: 'get',

        response: () => {

            return userInfoData[0]

        },

    },
    {

        url: '/api/notice',

        method: 'get',

        response: () => {

            return noticeData

        },

    },
    {

        url: '/api/dynamic',

        method: 'get',

        response: () => {

            return dynamicData

        },

    },
    {

        url: '/api/teachingResearch/teaching',

        method: 'get',

        response: () => {

            return teachingData

        },

    },

] as MockMethod[];
