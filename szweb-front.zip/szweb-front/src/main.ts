import { createApp } from 'vue'

import App from './App.vue'

import * as echarts from 'echarts'

import 'mosha-vue-toastify/dist/style.css'

import 'material-design-icons-iconfont/dist/material-design-icons.css'

// 全局引入Vuetify

import 'vuetify/styles'

import { createVuetify } from 'vuetify'

import * as components from 'vuetify/components'

import * as directives from 'vuetify/directives'

import { aliases, md } from 'vuetify/iconsets/md'

import router from './router'

import {setupStore} from "./store";

const vuetify = createVuetify({

  components,

  directives,

  icons: {

    defaultSet: 'md',

    aliases,

    sets: {

      md,

    }

  },

})

const app=createApp(App)

app.use(vuetify)

setupStore(app)

app.use(router)

app.mount('#app')

app.config.globalProperties.$echarts = echarts