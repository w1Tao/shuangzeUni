import {defineStore} from "pinia";

import { getToken, setToken,removeToken } from '../../utils/auth'

import {login,getInfo} from '../../api/user'

import type {User} from "../../store/type";

import {createToast} from "mosha-vue-toastify";

interface UserStoreType{

    token:string,

    user:User

    errorMessage:string

}

export const useUserStore = defineStore('user-store', {

    state: ():UserStoreType => ({

        token: getToken() || '',

        user:{},

        errorMessage:''

    }),

    actions: {

        async login(userInfo: { username: string; password: string}) {

            const {data}=await login(userInfo.username, userInfo.password)

            if(data.errno){

                createToast("登录失败："+data.message, {position: 'top-center', showIcon: true})

                return

            }

            setToken(data.token)

            this.token= data.token

        },

        // 获取用户信息

        async getInfo() {

            const { data } = await getInfo()

            this.user= data

        },

        async logout(){

            this.token=''

            removeToken()

            this.user={}

        }

    }

})