import {defineStore} from "pinia";

 

export const useAppStore = defineStore('app-store', {

    persist: true,

    state: () => ({

        toggle:false,

        listUrl: '',

        listType: '',

        name:'',

        title:'',

        icon:'',

        // editData:{},

        itemContent:{content:'',title:'',updateTime:'',hit:0},

        uploadFileUrl:import.meta.env.VITE_BASE_URL+'/uploadFile'

    }),

 

    actions: {

        setUrl(data:any) {

            this.listUrl= data.url

            this.listType= data.type

            this.icon=data.icon

        },

        setTitle( data:any) {

            this.name=data.name

            this.title=data.title

        },

        setContent(data:any) {

           this.itemContent= data

 

        }

    }

},)