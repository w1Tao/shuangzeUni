export interface Breadcrumb{

    text:string,disabled:boolean,href:string

}