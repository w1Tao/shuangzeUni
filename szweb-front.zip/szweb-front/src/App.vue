<script setup lang="ts">

</script>

<style scoped>

body {

    font-size: 16px;

    font-family: "Microsoft YaHei", "微软雅黑", "arial", "tahoma", "MicrosoftJhengHei";

    font-weight: 400;

    background: #E8EAEd !important;

}

</style>
 

<template>

 <router-view>

 </router-view>

</template>