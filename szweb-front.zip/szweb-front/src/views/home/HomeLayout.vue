<template>

  <v-app >

      <home-header :flat="flat"/>

      <v-main class="main">

          <router-view v-slot="{ Component }">

              <transition name="scroll-x-transition">

                  <component :is="Component"/>

              </transition>

          </router-view>

      </v-main>

      <home-footer :height="90"/>

  </v-app>

</template>



<script lang="ts" setup>

import HomeHeader from "./components/HomeHeader.vue";

import HomeFooter from "./components/HomeFooter.vue";

import {ref} from "vue"

import {useEventListener} from "@vueuse/core"

const flat = ref(true)

useEventListener(window, 'scroll', () => {

  let scrollTop =

      window.scrollY ||

      document.documentElement.scrollTop ||

      document.body.scrollTop;

  if (scrollTop > 10) {

      flat.value = false;

  }

  if (scrollTop === 0) {

      flat.value = true;

  }

})

</script>



<style scoped>

.main {

  background: url("@/assets/images/bg.png");

}

</style>