<template>

  <div id="header">

    <sz-drawer :menus="menus" v-if="showDrawer"/>

    <v-app-bar :color="color" :flat="flat" height="100">

      <router-link :to="{name:'home'}" class="d-flex align-center">

        <img alt="" class="ml-3" height="60" :src="logo">

      </router-link>



      <v-spacer></v-spacer>

      <template v-for="menu in menus" v-if="!isMobile">

        <v-menu v-if="menu.items" open-on-hover transition="fab-transition">

          <template v-slot:activator="{ props }">

            <v-btn class="text-subtitle-1"
                   @click="handleClick(menu)"
                   color="#fff"

                   v-bind="props">
              <v-icon :icon="menu.icon" class="mr-2" style="margin-bottom: -4px"/>

              {{ menu.title }}

            </v-btn>

          </template>

          <template #default>

            <v-list>

              <v-list-item v-for="subMenu in menu.items" width="130">

                <v-icon color="#005eb6" :icon="subMenu.icon"/>

                {{ subMenu.title }}

              </v-list-item>

            </v-list>

          </template>

        </v-menu>

        <v-menu :key="menu.title" v-else>

          <template v-slot:activator="{ props }">

            <v-btn class="text-subtitle-1"

                   color="#fff"
                   @click="handleClick(menu)"
                   v-bind="props">

              <v-icon :icon="menu.icon" class="mr-2" style="margin-bottom: -4px"/>

              {{ menu.title }}

            </v-btn>

          </template>

        </v-menu>

      </template>

      <v-btn icon="more_vert" color="#fff" class="" @click.stop="showDrawer=!showDrawer" to="" v-if="isMobile">

      </v-btn>

      <v-menu v-if="!isMobile" open-on-hover>

        <template v-slot:activator="{ props}">

          <v-btn color="#fff" icon="menu" v-bind="props">

          </v-btn>

        </template>

        <v-list>

          <v-list-item :to="item.path" v-for="item in menuItems">

            <v-list-item-title  >

              <v-icon color="#005eb6" :icon="item.icon"/>

              {{ item.title }}

            </v-list-item-title>

          </v-list-item>

        </v-list>

      </v-menu>

    </v-app-bar>

  </div>

</template>



<script lang="ts" setup>

import SzDrawer from '@/views/home/components/SzDrawer.vue'
import {addStatistics} from "@/api/statistics"


import {getFrontMenus} from '../components/menu'

import {useDisplay} from "vuetify"

import {computed, reactive, ref} from "vue"

import logo from "@/assets/images/shuangzexx.png"

import {createToast} from "mosha-vue-toastify";



withDefaults(defineProps<{ color?: string, flat?: boolean }>(), {color: '#17406d', flat: true})

const {name} = useDisplay()

const isMobile = computed(() => {

  return name.value === 'xs' || name.value === 'md' || name.value === 'sm'

})

const showDrawer=ref(false)

const menus = ref()

const menuItems = ref([

  {title: '登录', icon: 'meeting_room', path: {path: '/login'}},

  {title: '注册', icon: 'person_add', path: {path: '/register'}}

])
const handleClick = async (item) =>{
  await  addStatistics(item.name,item.title)
}
const getMenus = async () => {

  try {

    const {data} = await getFrontMenus()

    menus.value = data.content

  } catch (e: any) {

    createToast(e.toString)

    console.log(e)

  }

}

getMenus()

</script>

<style scoped>

  .v-app-bar img {

      filter: drop-shadow(2px 1px 2px rgba(0, 0, 0, 0.8));

  }

</style>

