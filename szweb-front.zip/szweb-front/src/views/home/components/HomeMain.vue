<template>

    <div id="main">
  
      <v-carousel  :cycle="true" height="auto" :show-arrows="false" :hide-delimiter-background="true">
  
        <a class="cursor" v-for="(item,i) in carousels.items"  >
  
          <v-carousel-item :key="i"  :src="item.imgUrl" >
  
          </v-carousel-item>
  
        </a>
  
      </v-carousel>
  
      <v-container fluid >
  
        <v-card>
  
          <v-row justify="center">
  
            <v-col :key="parentIndex" cols="12" lg="4"  v-for="(item,parentIndex) in mainContent">
  
              <v-card flat :class="[{item1:parentIndex===0},{item2:parentIndex===1},{item3:parentIndex===2}]"
  
                      min-height="450">
  
                <nav class="d-flex justify-space-between mt-3 " :class="[{divTitle1:parentIndex===0},{divTitle2:parentIndex===1},{divTitle3:parentIndex===2}]">
  
                  <h3 class="text-h6">
  
                    {{ item.name }}
  
                  </h3>
  
                  <span style="margin-bottom: -1px">
  
                       <a variant="text" class="cursor" @click.stop="useHandleMenu(item.icon,item.url,item.type)" >more</a>
  
                  </span>
  
                </nav>
  
                <section>
  
                  <v-list>
  
                      <v-list-item v-for="(subItem,subIndex) in item.items" >
  
                        <v-list-item-title class="d-flex" :title="subItem.title">
  
                          <v-icon  :class="[{title1:parentIndex===0},{title2:parentIndex===1},{title3:parentIndex===2}]" icon="fiber_manual_record"></v-icon>
  
                          <span class="ml-2 title-cell text-no-wrap">{{ subItem.title }}</span><v-spacer></v-spacer> <span>{{ formatDate(subItem.updateTime) }}</span>
  
                        </v-list-item-title>
  
                        <v-divider  v-if="subIndex!==9&&item.items.length!==0" class="mt-4"></v-divider>
  
                      </v-list-item>
  
   
  
                  </v-list>
  
                </section>
  
              </v-card>
  
            </v-col>
  
          </v-row>
  
        </v-card>
  
   
  
      </v-container>
  
      <div class="graduate-back mt-4">
  
        <v-container grid-list-xl>
  
          <v-row justify="center" class="mb-3">
  
            <v-btn variant="text"   class="b-border text-blue-darken-3 text-h6  text-center  mb-3">
  
              <v-icon icon="movie_filter" class="mr-2"></v-icon>
  
              {{ graduates.name }}
  
            </v-btn>
  
          </v-row>
  
          <v-row justify="center" >
  
            <v-col :key="i" class="mb-4" v-for="(graduate,i) in graduates.items" >
  
              <v-hover v-slot="{ isHovering, props }">
  
                <v-card :elevation="isHovering ? 12 : 2" class="rounded-circle">
  
                  <a class="cursor">
  
                    <v-img :key="i" :src="graduate.imgUrl" v-bind="props">
  
                      <v-expand-transition>
  
                        <div class="d-flex text-center flex-column justify-end transition-fast-in-fast-out bg-white v-card--reveal text-h5  text-black"
  
                            style="height: 100%;"
  
                            v-if="isHovering"
  
                        >
  
                          <span class="mb-5">{{ graduate.title }}</span>
  
                        </div>
  
                      </v-expand-transition>
  
                    </v-img>
  
                  </a>
  
                </v-card>
  
              </v-hover>
  
            </v-col>
  
          </v-row>
  
        </v-container>
  
      </div>
  
    </div>
  
  </template>
  
  <script lang="ts" setup>
  
  import {formatDate} from '../../../utils/formatDate'
  
  import {getHome} from '../../../api/home'

  import {useHandleMenu} from "../../../hooks/useHandleMenu"
  
  import { ref} from "vue"
  
   
  
  import {createToast} from "mosha-vue-toastify"
  
  const mainContent = ref([])
  
  const graduates = ref([])
  
  const carousels=ref([])
  
  const getData = async () => {
  
    try {
  
      const {data} = await getHome()
  
      console.log(data)
  
      mainContent.value = data[0].items
  
      carousels.value = data[2]
  
      graduates.value = data[1]
  
      console.log(graduates)
  
    } catch (e: any) {
  
      createToast(e.toString)
  
    }
  
  }
  
  getData()
  
   
  
  </script>
  
   
  
  <style  scoped>
  
  .cursor {
  
      cursor:pointer;
  
  }
  
  .b-border {
  
      border-bottom:2px solid #ed790d;
  
      text-decoration: none;
  
  }
  
  .title1 {
  
      color:#199e49;
  
  }
  
  .title2{
  
    color:#4a5334;
  
  }
  
  .title3 {
  
      color: #9a1d25;
  
  }
  
  .title-cell {
  
      white-space:nowrap;
  
      overflow:hidden;
  
      text-overflow:ellipsis;
  
      padding-right:10px;
  
  }
  
  .mt20 {
  
      margin-top:20px;
  
      background-color:#747bff;
  
  }
  
  .v-card--reveal {
  
      align-items:center;
  
      bottom:0;
  
      justify-content:center;
  
      opacity: .7;
  
      position: absolute;
  
      width:100%;
  
  }
  
  .item1 {
  
      padding:20px 20px 20px 40px
  
  }
  
  .item2 {
  
      padding:20px;
  
  }
  
  .item3 {
  
      padding:20px 40px 20px 20px;
  
  }
  
  .v-footer {
  
      position:relative;
  
      margin-bottom: -3px;
  
      justify-content: center;
  
  }
  
  .v-content {
  
      background:#d8e7f7 !important;
  
  }
  
  .divTitle2
  
   {
  
      color: #4a5334;
  
      border-bottom: 2px solid #4a5334;
  
  }
  
  .divTitle2 span {
  
        background: #4a5334 !important;
  
    }
  
  .divTitle1 {
  
      color: #199e49;
  
      border-bottom:2px solid #199e49;
  
  }
  
  .divTitle1 span {
  
        background: #199e49 !important;
  
    }
  
  .divTitle3 {
  
      color:#9a1d25;
  
      border-bottom:2px solid #9a1d25;
  
  }
  
  .divTitle3 span {
  
        background: #9a1d25 !important;
  
    }
  
  .divTitle1 a,.divTitle2 a,.divTitle3 a {
  
      padding:5px;
  
      color: #fff;
  
      font-size: 16px;
  
      line-height: 32px;
  
      text-decoration:none;
  
  }
  
  .divTitle1 span,.divTitle2 span,.divTitle3 span {
  
      margin-bottom:-1px;
  
  }
  
  </style>