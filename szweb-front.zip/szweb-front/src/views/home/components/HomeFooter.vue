<template>

 

    <footer :style="`background-color:${bg};height:${height}px`"  class="d-flex  justify-center align-center  text-white">

 

        <img src="@/assets/images/logo.png"  alt="">

 

      <section class=" d-flex flex-column justify-center align-center ">

        <span   class="text-white d-none d-md-flex"><a href="#">学校主页</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#">学院首页</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a

            href="javascript:void(0);" onclick="setHome(this,'http://localhost');">设为首页</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a

            href="javascript:void(0);" onclick="addFavorite('我的网站',location.href)">加入收藏</a></span>

        <span>Copyright © 2022&nbsp;&nbsp;双泽信息学院&nbsp;&nbsp;版权所有</span>

      </section>

 

        <img src="@/assets/images/url.png"    alt="">

 

    </footer>

 

</template>

 

<script lang="ts" setup>

interface Props{

  height?:number,

  bg?:string

}

withDefaults(defineProps<Props>(),{

  height:90,bg:'#2d4759'

})

 

</script>

<style  scoped>

footer a{

    color: #fff;

    text-decoration: none;

}

footer img {

    filter: drop-shadow(2px 1px 2px rgba(0, 0, 0, 0.8));

    height: 60px;

    width: auto;

}

footer section{

    border-right: #1c1c1c 1px solid;

    border-left: #1c1c1c 1px solid;

    padding-right: 20px;

    padding-left: 20px;

    margin-left: 16px;

    margin-right: 20px;

}

 

</style>