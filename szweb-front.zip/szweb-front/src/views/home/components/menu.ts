import {SEWEB} from "@/api/config";



export async function getFrontMenus() {

    return SEWEB.request({

        url: '/menus',

        method: 'get',

    })

}
