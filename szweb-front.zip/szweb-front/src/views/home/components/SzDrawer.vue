<template>

    <v-navigation-drawer app

                         width="248"

                         id="appDrawer"

                         right v-model="drawer" :rail="mini">

        <template v-slot:prepend v-if="showTitle">

            <v-toolbar class="bg-blue-darken-3" :elevation="2" >

                <router-link :to="{name:'admin'}" class="d-flex align-center">

                    <img alt="Admin" class="admin-logo" height="45" :src="logo">

                </router-link>

            </v-toolbar>

        </template>

        <v-list density="compact" >

            <template v-for="menu in menus" >

                <v-list-group model-value="1"    v-if="menu.items">

                    <template v-slot:activator="{props}">

                        <v-list-item  active-color="primary"
                                      v-bind="props" :prepend-icon="menu.icon" :title="menu.title">

                        </v-list-item>

                    </template>

                    <v-list-item  v-for="subMenu in menu.items" :prepend-icon="subMenu.icon" :title="subMenu.title"  active-color="primary"  @click="(subMenu.icon,menu.name,subMenu.name,isAdmin)">



                    </v-list-item>

                </v-list-group>

                <v-list-item v-else :prepend-icon="menu.icon" :title="menu.title" @click="handleClick(menu,isAdmin)">



                </v-list-item>

            </template>

        </v-list>

    </v-navigation-drawer>

</template>



<script setup lang="ts">

import logo from '../../../assets/images/shuangzexx.png'

import {ref, withDefaults} from "vue"
import router from "@/router";
import {createToast} from "mosha-vue-toastify";
withDefaults(defineProps<{menus:[],mini?:boolean,showTitle?:boolean,isAdmin?:boolean}>(),{mini:false,showTitle:false,isAdmin:false})

const drawer=ref(true)
// menuName,subMenuName,isAdmin
const handleClick = async function (menu,isAdmin){
  if (isAdmin){
    await router.push({path: "/admin/" + menu.name})
  }else {
    createToast('你无权访问此板块', {position: 'top-center', showIcon: true})
  }

}
</script>



<style  scoped >

.admin-logo{

    filter: drop-shadow(2px 1px 2px rgba(0, 0, 0, 0.8));

}

.v-icon{

    color: #005eb6;

}

</style>
