<template>

  <data-table :isAdmin="false" :headers="headers"/>

</template>



<script lang="ts" setup>

import DataTable from "@/components/DataTable.vue"

const headers = ['标题',  '更新时间']

</script>
