<template>
  <div>
    <div ref="main" style="width: 100%; height: 80vh"></div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import { findAllStatistics } from '@/api/statistics'
import * as echarts from "echarts";

const main = ref();
onMounted(async () => {
  const { data } = await findAllStatistics();
  init(data);
})

function init(data) {
  console.log(data.map(item => {
    return {value:item.menuNumber,name:item.menuName}
  }))
  var myChart = echarts.init(main.value);
  var option = {
    title: {
      text: '用户点击统计数据',
      left: 'center'
    },
    tooltip: {
      trigger: 'item'
    },
    legend: {
      orient: 'vertical',
      left: 'left'
    },
    textStyle:{
      fontSize:20
    },
    series: [
      {
        name: 'Access From',
        type: 'pie',
        radius: '80%',
        data: data.map(item => {
          return {value:item.menuNumber,name:item.menuName}
        }),
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };
  myChart.setOption(option);
  window.addEventListener("resize", () => {
    myChart.resize();
  });
}
</script>

<style scoped>
body {
  margin: 0;
}
</style>
