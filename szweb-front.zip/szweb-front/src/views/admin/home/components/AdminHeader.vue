<template>

    <v-app-bar :height="height"
  
        app
  
        fixed :elevation="2" class="text-blue-darken-3">
  
      <v-app-bar-nav-icon :class="['slider-trigger-a', collapsed ? 'collapsed' : '']"
  
                          @click.stop="handleDrawerToggle"></v-app-bar-nav-icon>
  
      <v-toolbar-title class="ml-0 pl-3">
  
        <span class="hidden-sm-and-down pl-10">管理控制台</span>
  
      </v-toolbar-title>
  
   
  
      <v-spacer></v-spacer>
  
      <v-menu  open-on-hover  transition="fab-transition">
  
        <template v-slot:activator="{ props}">
  
          <v-btn v-bind="props">
  
            <v-avatar size="30px">
  
              <img :src="user.avatar||defaultAvatar" height="30"/>
  
            </v-avatar>
  
          </v-btn>
  
        </template>
  
        <v-list class="pa-0">
  
            <v-list-item v-for="(item) in items" @click="item.click" ripple="ripple">
  
              <v-list-item-title>
  
                <v-icon color="#005eb6" :icon="item.icon"></v-icon>
  
                {{ item.title }}
  
              </v-list-item-title>
  
            </v-list-item>
  
        </v-list>
  
      </v-menu>
  
      <v-btn href="mailto:ljy@hainu.edu.cn" icon="mail">
  
      </v-btn>
  
   
  
      <v-btn @click="toggle" icon="fullscreen">
  
      </v-btn>
  
   
  
    </v-app-bar>
  
  </template>
  
  <script lang="ts" setup>
  
  import {useUserStore} from "../../../../store";
  
  import {ref, toRefs} from "vue";
  
  import {useRouter} from "vue-router";
  
  import {useFullscreen} from "@vueuse/core";
  
  import defaultAvatar from '@/assets/images/test.jpg'
  
  import {storeToRefs} from "pinia";
  
   
  
  defineProps<{height:number}>()
  
  const {logout} =useUserStore()
  
  const {user} =storeToRefs(useUserStore())
  
  const collapsed = ref(false)
  
  const router = useRouter()
  
  const items = ref([
  
    {
  
      icon: 'account_circle',
  
      href: '#',
  
      title: '个人空间',
  
      click: () => {
  
        router.push({path: '/space'})
  
      }
  
    },
  
    {
  
      icon: 'fullscreen_exit',
  
      href: '#',
  
      title: '退出登录',
  
      click: async () => {
  
        await logout()
  
        await router.replace({path: '/'})
  
   
  
      }
  
    }])
  
  const emit = defineEmits([('onToggle')])
  
  const handleDrawerToggle = () => {
  
    collapsed.value = !collapsed.value
  
    emit('onToggle');
  
  }
  
  const {toggle} = useFullscreen();
  
   
  
  </script>
  
  <style  scoped>
  
  .v-toolbar {
  
      box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.4), 0px 2px 6px rgba(0, 0, 0, 0.4);
  
  }
  
  .trans {
  
      transition: transform .2s ease;
  
  }
  
   
  
  </style>