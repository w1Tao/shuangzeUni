<template>

    <footer  class="d-flex  justify-center align-center"  >

            <span>双泽软件工作室</span>

            <span>&nbsp;版权所有</span>

            <span>&nbsp;&nbsp;&copy; 2018</span>

    </footer>

</template>

 

<script lang="ts" setup>

 

  withDefaults(defineProps<{height?:number,bg?:string}>(),{height:50,bg:'#fff'})

 

</script>

 

<style scoped >

footer{

  height:v-bind(height+'px');

  background:v-bind(bg);

}

 

</style>