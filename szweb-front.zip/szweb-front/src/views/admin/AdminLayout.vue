<template>

    <v-app id="admin">

      <sz-drawer :show-title="true" :menus="menus" :mini="mini" :is-admin="true"></sz-drawer>

      <admin-header :height="headerHeight" @onToggle="mini=!mini" ></admin-header>

      <v-main>

          <v-container fluid justify="center" class="admin-main" :style="`min-height: calc(100vh - ${headerHeight+footerHeight}px)`">

            <router-view  v-slot="{ Component }" >

              <transition name="scroll-x-transition">

                <component :is="Component"/>

              </transition>

            </router-view>

          </v-container>

          <admin-footer :height="footerHeight" ></admin-footer>

      </v-main>

    </v-app>

  </template>

  <script lang="ts" setup>

  import SzDrawer from '../home/components/SzDrawer.vue'

  import AdminHeader from './home/components/AdminHeader.vue'

  import AdminFooter from './home/components/AdminFooter.vue'

  import { ref} from "vue";

  import {getBackMenus} from "../../api/menu";

  import {useRouter} from "vue-router";

  const mini=ref(false)

  const menus = ref([])

  const headerHeight=64

  const footerHeight=50

  const getMenus = async () => {

    const {data} = await getBackMenus()

    menus.value = data

  }

  const router=useRouter()



  getMenus()
  </script>



  <style  >

  .v-dialog__content {

    z-index: 203 !important;

  }

  .admin-main{

      background-color:#E8EAED;

  }



  </style>
