<script lang="ts" setup>

import { onMounted, ref, getCurrentInstance } from 'vue';

import { register} from '../api/user'

import { createToast } from "mosha-vue-toastify";

import { usernameRules, passwordRules, confirmPasswordRules, nameRules, mobileRules, emailRules, password } from "../hooks/useValidRule"


const show1 = ref(false)

let show2 = ref(false)

const username = ref('')

const confirmpassword = ref('')

const name = ref('')

const mobile = ref('')

const email = ref('')

const handleLogin = async () => {

  const { valid } = await instance.ctx.$refs.form.validate()

  if (valid) {

    if (username.value == '' || password.value == '' || confirmpassword.value == '' || name.value == '' || mobile.value == '' || email.value == '') {

      createToast('用户名或密码、姓名、电话、邮箱不能为空！', { position: 'top-center', showIcon: true })

    } else {


      try {

        const res = await register(username.value,password.value,name.value,mobile.value,email.value)
        console.log(res)
        if (res.status == 200){
          createToast("注册成功", { position: 'top-center', showIcon: true })
        }else {
          createToast("注册失败", { position: 'top-center', showIcon: true })
        }

      } catch (e) {

        alert(e)

      }

    }

  }

}

let instance: any

onMounted(() => {

  instance = getCurrentInstance()

})

const reset = () => {

  instance.ctx.$refs.form.reset()

}

</script>

<style>
.home {
  background: rgb(230,230,230);
  font-size: small;
  width: 500px;
  height: 50px;
  vertical-align: middle;
  display: table-cell;
  padding-left: 20px;
}

.register {
  opacity: 0.5;
}
</style>

<template>
  <v-container class="h-100  d-flex align-center justify-center">

    <v-card width="500">

      <template v-slot:title>
        <div class="home">
          <v-icon color="rgb(60, 60, 200)">home</v-icon>
          <front>&ensp;首页&ensp;>&ensp;</front>
          <front class="register">用户注册</front>
        </div>
      </template>

      <v-card-text class="pa-8">

        <v-form ref="form">

          <v-text-field variant="underlined" v-model="username" required :counter="20" label="账号" prepend-icon="person"
            :rules="usernameRules"></v-text-field>



          <v-text-field variant="underlined" v-model="password" required :counter="20" label="密码"
            :append-icon="show1 ? 'visibility' : 'visibility_off'" prepend-icon="lock" :type="show1 ? 'text' : 'password'"
            :rules="passwordRules" @click:append="show1 = !show1"></v-text-field>

          <v-text-field variant="underlined" v-model="confirmpassword" required :counter="20" label="确认密码"
            :append-icon="show2 ? 'visibility' : 'visibility_off'" prepend-icon="lock" :type="show2 ? 'text' : 'password'"
            :rules="confirmPasswordRules" @click:append="show2 = !show2"></v-text-field>

          <v-text-field variant="underlined" v-model="name" required :counter="20" label="姓名" prepend-icon="portrait"
            type="text" :rules="nameRules"></v-text-field>

          <v-text-field variant="underlined" v-model="mobile" required :counter="20" label="手机" prepend-icon="smartphone"
            type="text" :rules="mobileRules"></v-text-field>

          <v-text-field variant="underlined" v-model="email" required :counter="20" label="邮箱" prepend-icon="mail"
            type="text" :rules="emailRules"></v-text-field>

          <v-row class="mt-5">

            <v-btn class="ml-5" @click="handleLogin">提交</v-btn>

            <v-btn class="ml-5" @click="reset">复位</v-btn>

          </v-row>

        </v-form>

      </v-card-text>

    </v-card>

  </v-container>
</template>

<style scoped></style>
