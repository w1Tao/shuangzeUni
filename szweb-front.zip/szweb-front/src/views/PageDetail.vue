<template>

  <v-container class="w-100">

    <v-card min-height="450" class="w-100">

      <title-bar :items="breadcrumbs" :icon="icon">

      </title-bar>

      <v-card-text class="text-center pa-4">

        <div class="text-h5 mt-4" v-text="itemContent.title"></div>

        <section class="mt-4">

          <span>阅读次数：{{ itemContent.hit + 1 }}</span>&nbsp;&nbsp;&nbsp;&nbsp;

          <span>发布时间：{{ formatDate(itemContent.updateTime) }}</span>

        </section>

        <v-divider class="mt-5"/>

        <p class="text-xs-left mt-3 pa-2" v-html="itemContent.content">

        </p>

      </v-card-text>

    </v-card>

  </v-container>



</template>



<script setup lang="ts">



import {useAppStore} from "../store";

import {formatDate} from '../utils/formatDate'

import TitleBar from "@/components/TitleBar.vue";

import {ref} from "vue";

import {storeToRefs} from "pinia";



let breadcrumbs = ref<Breadcrumb[]>([{text: '首页', disabled: false, href: '/'}])

const {itemContent, icon, listType, listUrl, title, name} = storeToRefs(useAppStore())

let url = listUrl.value

if (!!listType.value) {

  url = '/' + listUrl.value + '/' + listType.value

  breadcrumbs.value.push({text: title.value, disabled: true, href: '#'})

}

breadcrumbs.value.push({text: name.value, disabled: false, href: url})

breadcrumbs.value.push({text: '正文', disabled: true, href: '#'})

</script>



<style scoped>

.data-item {

  cursor: pointer;

}



.data-item:hover {

  color: orangered;

  transform: scale(1.5);

  animation-duration: 0.6s;

  animation-fill-mode: both;

  animation-name: zoomIn;

  direction: rtl;

}



@keyframes zoomIn {

  from {

    opacity: 0;

    transform: scale3d(.3, .3, .3);

  }



  50% {

    opacity: 1;

  }



}

</style>