// 1. 导入路由组件

import {createRouter, createWebHistory} from 'vue-router';



import {useUserStore} from '../store'

import {useTitle} from '@vueuse/core';

import {start, close} from '../utils/nprogress'

import {storeToRefs} from "pinia";




const routes = [



//动态加载，当路由被访问的时候才加载对应组件，这样就会更加高效

    {

        path: '/',

        component: () => import('@/views/home/HomeLayout.vue'),

        children: [

            // {
            //
            //   path:'test',
            //
            //   component:()=>import('@/components/GrandFather.vue')
            //
            // },

            {

                path: '',

                name:'home',

                meta: {title: '首页'},

                component: () => import('@/views/home/components/HomeMain.vue')

            },

            {

                path: 'login',

                meta: {title: '用户登录'},

                component: () => import('../components/UserLogin.vue')

            },

            {

                path: 'register',

                meta: {title: '用户注册'},

                component: () => import('../views/UserRegister.vue')

            },
            {

                path: '/test_editor',

                meta: {title: '在线编辑器测试'},

                component: () => import('@/components/TestEditor.vue')

            },
            {

                path: '/pageDetail',

                name: 'pageDetail',

                meta: {title: '详情页'},

                component: () => import('@/views/PageDetail.vue')

            },

            {

                path: '/notice',

                name: 'notice',

                meta: {title: '通知通告列表'},

                component: () => import('@/views/PageList.vue')

            },

            {

                path: '/dynamic',

                name: 'dynamic',

                meta: {title: '学院动态列表'},

                component: () => import('@/views/PageList.vue')

            },

            {

                path: '/teachingResearch/teaching',

                name: 'teaching',

                meta: {title: '教学活动列表'},

                component: () => import('@/views/PageList.vue')

            },



        ]

    },

    {

        path: '/admin',

        name: 'admin',

        meta: {title: '内容管理系统'},

        component: () => import('@/views/admin/AdminLayout.vue'),
        children: [
            {
                path: '/admin/statistics',
                name: 'statistics',
                component:()=>import('@/views/admin/statistics/index.vue')
            }
        ]

    }

    ]

// 3. 创建路由实例并传递 routes 配置

// 你可以在这里输入更多的配置，但我们在这里

// 暂时保持简单

const router = createRouter({

// 4. 设置路由模式为 history 模式

    history: createWebHistory(),

    routes:routes, // routes:routes 的缩写

})

router.beforeEach((to, from, next) => {

    const {getInfo, logout} = useUserStore()

    const { token, user} = storeToRefs(useUserStore())

    start()

    if (token.value) {

        if (to.path === '/login' && user.value) {

            next({path: '/admin'})

        } else {

            if (user.value) {

                getInfo().then(() => { // 拉取用户信息

                    next()

                }).catch((err) => {

                    console.log(JSON.stringify(err) || '拉取用户信息错误')

                    logout().then(() => {

                        next({path: '/login'})

                    })

                })

            } else {

                next()

            }

        }

    } else if (to.path === '/admin') {

        next({path: '/login'})

    } else {

        next()

    }

})

router.afterEach(to => {

    close()

    useTitle('双泽信息学院-' + to.meta.title);

})



export default router
