import axios from 'axios'

import { createToast } from 'mosha-vue-toastify'

import {getToken} from "./auth";

import {start,close} from './nprogress'

 

// 创建axios实例

const baseUrl = import.meta.env.VITE_BASE_URL

 

const service = axios.create({

    baseURL: baseUrl,

    timeout: 10000 // 请求超时时间

})

 

// request拦截器

service.interceptors.request.use(

    config => {

        const token=getToken()

        if (token!=='') {

            config.headers!['Authorization'] = 'Bearer ' +token // 让每个请求携带自定义token 请根据实际情况自行修改

        }

        config.headers!['Content-Type'] = 'application/json'

        start()

        return config

    },

    error => {

        // Do something with request error

        console.log(error) // for debug

        Promise.reject(error)

    }

)

 

// response 拦截器

service.interceptors.response.use(

    response => {

        close()

        return response

    },

    error => {

        createToast(error.message+"："+error.response.data.message,{position:'top-center',showIcon:true})

        return Promise.reject(error)

    }

)

 

export default service