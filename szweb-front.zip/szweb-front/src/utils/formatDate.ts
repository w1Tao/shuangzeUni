export function formatDate(value:any){

    const date = new Date(value);

    const year = date.getFullYear();

    const month = date.getMonth() + 1;

    const day = date.getDate();

    let month1

    let day1

    if (month < 10) {

        month1 = "0" + month;

    }else{

        month1=month

    }

    if (day < 10) {

        day1 = "0" + day;

    }else{

        day1=day

    }

    return year + "-" + month1 + "-" + day1;

}