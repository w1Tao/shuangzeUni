import request from '../utils/request'


export async function getBackMenus() {

    return request({

        url: 'http://localhost:8080/api/backMenus',

        method: 'get',

    })

}
