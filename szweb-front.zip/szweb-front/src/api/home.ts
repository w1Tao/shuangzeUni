import request from '../utils/request'



export async function getHome() {

    return request({

        url: '/api/home',

        method: 'get',

    })

}

