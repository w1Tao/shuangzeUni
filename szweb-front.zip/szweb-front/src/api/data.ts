import {SEWEB} from "./config"


export async function getList(url:string, params:{}, type:string) {
    if (url === "notice"){
        url = "/public/notices"
    } else if (type) {
        url = "/" + url + '/' + type
    }


    // url === 'user' || url === 'menu' ? url = '/' + url : url = '/public/' + url



    return SEWEB.request({

        url: url,

        method: 'get',

        params: params

    })

}

export async function addHit(url:string, id:string) {

    url = '/public/' + url + '/' + id

    return SEWEB.request({

        url: url,

        method: 'put'

    })

}

export async function update(data:{}, url:string) {

    console.log(data)

    return SEWEB.request({

        headers: {

            'Content-Type': 'application/json; charset=utf-8'

        },

        url: url,

        method: 'put',

        data

    })

}



export async function add(data:{}, url:string, type = '') {

    url = url + '/' + type

    return SEWEB.request({

        url: url,

        method: 'post',

        data

    })

}

export async function del(id:string, url:string) {

    return SEWEB.request({

        url: url + '/' + id,

        method: 'delete'

    })

}
