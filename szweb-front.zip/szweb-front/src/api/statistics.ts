import {Statistics} from "./config"
export  async  function  findAllStatistics(){
    return Statistics.request({
        url : "/statistics",
        method: 'get',
    })
}



import { Md5 } from 'ts-md5';

export  async  function  addStatistics(name :string,title:string){
    return Statistics.request({
        url : "/statistics",
        method: 'post',
        data :{
             id:Md5.hashStr(name + title),
             menuName:title,
             menuNumber:1
        }
    })
}
