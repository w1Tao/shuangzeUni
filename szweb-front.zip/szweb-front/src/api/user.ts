import {SEWEB} from "./config"



export async function login(username:string, password:string) {

    return SEWEB.request({

        // url: 'api/login',
        url : "/auth/login",

        method: 'post',

        data: {

            username,

            password

        }

    })

}

export async function getInfo() {

    return SEWEB.request({

        url: '/auth/info',

        method: 'get'

    })

}

export async function register(username:string,password:string,name:string,phone:string,email:string) {

    return SEWEB.request({

        url: '/auth/register',

        method: 'post',

        data: {

            username,

            password,

            name,

            phone,

            email,

        }

    })

}
