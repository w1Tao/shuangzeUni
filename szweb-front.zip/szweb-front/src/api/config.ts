import service from '../utils/request'

const BaseApiUrl = "http://127.0.0.1:9000"
export const SEWEB ={
    request(op){
        op.url = BaseApiUrl + "/seweb-main" + op.url
        return service(
            op
        )
    }
}   
export const Statistics ={
    request(op){
        op.url = BaseApiUrl + "/seweb-statistics" + op.url
        return service(
            op
        )
    }
}
