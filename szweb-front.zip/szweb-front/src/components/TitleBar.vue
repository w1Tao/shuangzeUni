<template>

  <v-toolbar>

    <v-breadcrumbs :items="items" divider=">">

      <template v-slot:prepend>

        <v-icon color="primary" class="ml-4" size="small" :icon="icon"></v-icon>

      </template>

    </v-breadcrumbs>

    <slot></slot>

  </v-toolbar>

</template>



<script lang="ts" setup>

import type { Breadcrumb } from "../types/globle"



withDefaults(defineProps<{ icon?: string,items:Breadcrumb[]}>(),{icon:'home'})

</script>