<template>

    <v-container>

        <sz-editor v-model="content"></sz-editor>

        <p class="pa-5" v-html="content">

 

        </p>

    </v-container>

</template>

 

<script lang="ts" setup>

import SzEditor from "@/components/SzEditor.vue"

import {ref} from "vue";

const content=ref('')

</script>

 

<style scoped>

</style>