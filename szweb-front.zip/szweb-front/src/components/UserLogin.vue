<script lang="ts" setup>

import {onMounted, ref, getCurrentInstance} from 'vue';

import {createToast} from "mosha-vue-toastify";

import {usernameRules ,passwordRules} from '../hooks/useValidRule'

import {VForm} from "vuetify/components";

import {useUserStore} from "../store";

import {storeToRefs} from "pinia";

import {useRouter} from "vue-router";

const password = ref('')

const username = ref('')

let instance:any

onMounted(() => {

    instance = getCurrentInstance()

})

const router=useRouter()

const {token}=storeToRefs(useUserStore())

const handleLogin = async () => {

    const {valid} = await instance.ctx.$refs.form.validate();
    console.log(valid)

    if (valid) {

        const user = { username:username.value, password:password.value}

        const {login,getInfo}=useUserStore()

        try {

            await login(user)

            if(token){

                await getInfo()

                await router.push({path:'/admin'})

            }



        }

        catch (e:any){

            reset()

        }

    }

}

const reset = () => {

    instance.ctx.$refs.form.reset()

}

</script>

<template>

  <v-container class="h-100  d-flex align-center justify-center">

    <v-card width="500">

      <v-card-title>用户登录</v-card-title>

      <v-card-text class="pa-8">

        <v-form ref="form">

          <v-text-field variant="underlined" v-model="username" required

                        :counter="20"

                        label="账号"

                        prepend-icon="person"

                        :rules="usernameRules"

          ></v-text-field>



          <v-text-field variant="underlined" v-model="password" required

                        :counter="20"

                        label="密码"

                        prepend-icon="lock"

                        type="password"

                        :rules="passwordRules"

          ></v-text-field>

          <v-row class="mt-5">

            <v-btn class="ml-5" @click="handleLogin">提交</v-btn>

            <v-btn class="ml-5" @click="reset">复位</v-btn>

          </v-row>

        </v-form>



      </v-card-text>

    </v-card>



  </v-container>

</template>

<style scoped>



</style>
