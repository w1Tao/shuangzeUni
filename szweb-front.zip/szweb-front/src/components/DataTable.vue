<template>

  <v-container class="h-100">

    <v-row align="center" justify="center">

      <v-col xs="12">

        <v-card min-height="450">

          <title-bar :items="titleItems" :icon="icon" href="/admin">

            <v-spacer/>

            <v-col cols="2">

              <v-text-field v-model="search" :loading="loading"

                            density="compact"

                            variant="solo"

                            append-inner-icon="search"

                            single-line

                            hide-details

                            label="输入标题中的关键字搜索"

                            @click:append-inner="handleSearch"

              ></v-text-field>

            </v-col>

            <v-col class="ml-4" cols="2" >

              <v-btn prepend-icon="add_circle"  rounded="pill" @click.stop="addItem">

                添加

              </v-btn>



            </v-col>

            <v-col cols="2">

              <v-btn prepend-icon="settings" rounded="pill" @click.stop="settings=!settings">

                设置每页显示数量

              </v-btn>

            </v-col>

            <v-col >

              <v-btn-toggle v-model="pageModel" v-if="settings" >

                <v-btn v-for="item in pageItems" @click="size=item.title;settings=false">

                  {{ item.title }}

                </v-btn>

              </v-btn-toggle>

            </v-col>

          </title-bar>

          <v-card-text>

            <slot name="table"></slot>

            <v-table>

              <thead>

              <tr>

                <th v-for="item in headers">

                  {{ item }}

                </th>

              </tr>

              </thead>

              <tbody>

              <tr v-for="item in items">

                <td v-text="item.title" v-if="!isUser&&isAdmin">

                </td>

                <td v-if="!isAdmin">

                  <v-btn variant="text" v-text="item.title" class="text-decoration-none"  @click="toDetail(item)"></v-btn>

                </td>

                <td v-if="isCarousel">

                  <v-img :src="item.imgUrl"></v-img>

                </td>

                <template v-if="isUser">

                  <td v-text="item.username">

                  </td>

                  <td v-text="item.name">

                  </td>

                  <td v-text="item.email">

                  </td>

                  <td v-text="item.phone">

                  </td>

                  <td v-text="item.enabled?'是':'否'">

                  </td>

                  <td v-if="isUser" v-text="formatDate(item.createTime)">

                  </td>

                </template>

                <template v-if="isMenu">

                  <td v-text="item.name">

                  </td>

                  <td v-text="item.parent">

                  </td>

                  <td>

                    {{ item.icon }}

                  </td>

                </template>

                <td v-if="!isUser" v-text="formatDate(item.updateTime)">

                </td>

                <td v-if="isAdmin">

                  <v-btn icon="edit" size="x-small" class="mr-4" @click.stop="editItem(item)"></v-btn>

                  <v-btn icon="delete" size="x-small" class="mr-4" @click.stop="deleteItem(item.id)"></v-btn>

                </td>

              </tr>

              </tbody>

            </v-table>

          </v-card-text>

          <v-pagination class="mb-5"

                        size="small" rounded="circle"

                        v-model="page"

                        :length="length"

                        @update:modelValue="onPageChange"

          ></v-pagination>

        </v-card>

      </v-col>

    </v-row>

    <v-dialog v-model="dialog" scrollable persistent :class="{'full-screen':fullScreen,'init-screen':!fullScreen}">

      <v-card min-width="500px">

        <v-toolbar color="primary">

          <v-card-title class="ml-2"> {{ formTitle }}</v-card-title>

          <v-spacer></v-spacer>

          <v-btn icon="fullscreen" class="mr-3" @click="fullScreen=!fullScreen"></v-btn>

        </v-toolbar>

        <v-card-text>

          <v-form ref="form">

            <v-text-field v-if="!isUser" variant="underlined"

                          v-model="formData.title"

                          :rules="titleRules"

                          label="标题" required

            ></v-text-field>

            <slot :edItem="{formData,role,actionType,select}">

            </slot>

            <p v-if="!isUser&&!isMenu">内容：</p>

            <editor v-if="!isUser&&!isMenu" v-model="formData.content"></editor>

          </v-form>

        </v-card-text>

        <div class="d-flex justify-end mr-10 mb-10">

          <v-spacer/>

          <v-btn class="mr-5" @click="submit">

            提交

          </v-btn>

          <v-btn @click="close">取消</v-btn>

        </div>

      </v-card>

    </v-dialog>

  </v-container>

</template>

<script lang="ts" setup>

import type {Breadcrumb} from "../types/globle";

import {update, add, del, getList} from "../api/data";

import Editor from '@/components/SzEditor.vue'

import {titleRules} from "@/hooks/useValidRule"

import {computed, getCurrentInstance, nextTick, onMounted, reactive, ref, toRefs, watch} from "vue";

import {useAppStore} from "../store";

import {useRouter} from "vue-router";

import {createToast} from "mosha-vue-toastify";

import {formatDate} from '@/utils/formatDate'

import TitleBar from '@/components/TitleBar.vue'

import {storeToRefs} from "pinia";



interface Props {

  initSelect?: any[],

  initRole?: string,

  isCarousel?: boolean,

  url?: string,

  isUser?: boolean,

  isMenu?: boolean,

  headers?: [],

  isAdmin?:boolean

}

const {

  initSelect = [],

  initRole = 'ROLE_USER',

  isCarousel = false,

  url = '',

  isUser = false,

  isMenu = false,

  headers = ['标题', '更新日期', '操作'],

  isAdmin= true

} = defineProps<Props>()

const pageItems = [

  {

    title: 10

  },

  {

    title: 20

  },

  {

    title: 50

  }

]

const fullScreen = ref(false)

const pageModel = ref(0)

const settings = ref(false)

let dialog = ref(false)

let page = ref(1)

let size = ref(10)

let loaded = ref(false)

let role = ref('ROLE_USER')

let select = ref<any>([])

let formData = ref<any>()

let total = ref(0)

let loading = ref(false)

let items = ref<any[]>([])

let search = ref('')

let actionType = ref('')

let titleItems = ref<Breadcrumb[]>([])

const router = useRouter()

const currentRoute=reactive(router)

watch([() => size.value,currentRoute,items.value], () => {

      handleDataList()

    }

)

const length = computed(() => {

  return Math.ceil(total.value / size.value)

})

const formTitle = computed(() => actionType.value === 'edit' ? '编辑信息' : '添加信息')

const {setTitle, setContent} = useAppStore()

let {listUrl, listType, icon} = storeToRefs(useAppStore())

console.log(listUrl.value)



if(!icon.value){

  icon.value='save_alt'

}

const onPageChange = () => {

  handleDataList()

}

const handleSearch = async () => {

  loading.value = true

  const {data} = await getList(listUrl.value, {title: search}, listType.value)

  items.value = data.content

  total.value = data.totalElements

  await handleData(data)

  search.value = ''

  loading.value = false

  loaded.value = true

}

const toDetail = async (item:any) => {

  await setContent(item)

  await router.push('/pageDetail')

}

let handleData = async (data:any) => {

  titleItems.value=[]

  if(!isAdmin){

    titleItems.value=[{text:'首页',disabled:false,href:'/'}]

  }else{

    titleItems.value=[{text:'首页',disabled:false,href:'/admin'}]

  }



  if (data.parent) {

    titleItems.value.push({text: data.parent, disabled: true, href: '#'})

  }

  titleItems.value.push({text: data.name, disabled: true, href: '#'})

  await setTitle({name: data.name, title: data.type})

}

const close = () => {

  formData.value = {}

  dialog.value = false

  role.value= 'ROLE_USER'

}

const handleDataList = async () => {

  const {data} = await getList(listUrl.value, {pageIndex: page.value - 1, pageSize: size.value}, listType.value)

  total.value = data.totalElements

  items.value = data.content

  await handleData(data)

}

let instance:any

onMounted(() => {

  handleDataList()

  instance = getCurrentInstance()

})

const addItem = () => {

  formData.value = {}

  dialog.value = true

  actionType.value = 'add'

}

const editItem = (item:any) => {

  formData.value = Object.assign({}, item)

  if (isUser) {

    switch (item.authorities[0]) {

      case 'ROLE_ADMIN':

        role.value = '系统管理员'

        break

      case 'ROLE_USER':

        role.value = '普通用户'

        break

    }

  }

  if (isMenu) {

    select.value = []

    item.authorities.forEach((role:any)=> {

      switch (role) {

        case 'ROLE_ADMIN':

          select.value.push('系统管理员')

          break

        case 'ROLE_USER':

          select.value.push('普通用户')

          break

        case 'ROLE_PUBLIC':

          select.value.push('开放的')

          break

      }



    })

  }

  dialog.value = true

  actionType.value = 'edit'

}

const deleteItem = async (id:any) => {

  if (confirm('你确定要删除当前记录吗？')) {

    const {data} = await del(id, listUrl.value)

    await handleDataList()

  }

}



const submit = async () => {

  const {valid} = await instance.ctx.$refs.form.validate()

  if (!valid) return

  if (isUser) {

    let roles:any[] = []

    switch (initRole) {

      case 'ROLE_ADMIN':

        roles.push('ROLE_ADMIN')

        break

      case 'ROLE_USER':

        roles.push('ROLE_USER')

        break

    }

    formData.value.authorities = roles

  }

  if (isMenu) {

    let roles:any[] = []

    initSelect.forEach(item => {

      switch (item) {

        case 'ROLE_ADMIN':

          roles.push('ROLE_ADMIN')

          break

        case 'ROLE_USER':

          roles.push('ROLE_USER')

          break

        case 'ROLE_PUBLIC':

          roles.push('ROLE_PUBLIC')

          break

      }

      formData.value.authorities = roles

    })

  }

  if (isCarousel) {

    formData.value.imgUrl = url

  }

  if (actionType.value === 'edit') {

    const {data} = await update(formData, listUrl)

    try {

      if (!data.errno) {

        await handleDataList()

        createToast("数据修改成功！", {position: 'top-center', showIcon: true})

      } else {

        createToast(data.message, {position: 'top-center', showIcon: true})

      }

    } catch (err) {

      console.log(err)

      close()

      createToast("数据编辑失败！", {position: 'top-center', showIcon: true})

    }

  } else {

    const {data} = await add(formData, listUrl.value, listType)

    try {

      if (!data.errno) {

        await handleDataList()

        createToast("数据添加成功！", {position: 'top-center', showIcon: true})

      } else {

        createToast(data.message, {position: 'top-center', showIcon: true})

      }

    } catch (err) {

      createToast('数据添加失败！', {position: 'top-center', showIcon: true})

      close()

    }

  }

  close()

}

</script>



<style  scoped>

.full-screen{

  width:100%;

}



.init-screen {

  width:1024px;

}

</style>
