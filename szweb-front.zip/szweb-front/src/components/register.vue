<script lang="ts" setup>
import { passwordRules } from '../hooks/useValidRule';
import { usernameRules } from '../hooks/useValidRule';
import { nameRules } from '../hooks/useValidRule';
import { phoneRules } from '../hooks/useValidRule';
import { emailRules } from '../hooks/useValidRule';
import {register} from "../api/user";


import { onMounted, ref, getCurrentInstance,defineComponent } from 'vue';



import { createToast } from "mosha-vue-toastify";

const username = ref('')

const password = ref('')
const confirm = ref('')
const name = ref('')
const phone = ref('')
const email = ref('')

let instance: any

onMounted(() => {

  instance = getCurrentInstance()

})

const handleRegister = async () => {

  const { valid } = await instance.ctx.$refs.form.validate()


  if (valid) {

    if( name.value == '' ){

      createToast('名字不能为空！', { position: 'top-center', showIcon: true })

      }

    if (username.value == '' || password.value == '' || confirm.value == '') {

      createToast('用户名或密码不能为空！', { position: 'top-center', showIcon: true })

    }

    const {data}=await register(username,password,name,phone,email)
    console.log(data)
  }

}


const reset = () => {

  instance.ctx.$refs.form.reset()

}


</script>

<template>
  <v-container class="h-100  d-flex align-center justify-center">

    <v-card width="500" prepend-icon="home"  >

        <template v-slot:title >用户注册</template>
      <v-card-text class="pa-8">

        <v-form ref="form">

          <v-text-field variant="underlined" v-model="username" required
          :counter="20"
          label="账号"
            prepend-icon="account_circle"
            :rules="usernameRules">
        </v-text-field>




          <v-text-field variant="underlined" v-model="password" required
          :counter="20" label="密码"
           prepend-icon="lock"

           append-icon="visibility_off"

            type="password"
             :rules="passwordRules"

             >
            </v-text-field>


          <v-text-field variant="underlined" v-model="confirm" required
          :counter="20" label="确认密码"
           prepend-icon="lock"
            append-icon="visibility_off"
             type="password"
             :rules="passwordRules">
            </v-text-field>


          <v-text-field variant="underlined" v-model="name" required :counter="20"
          label="姓名"
          prepend-icon="person"
            type="text"
            :rules = "nameRules">
        </v-text-field>


          <v-text-field variant="underlined" v-model="phone" required :counter="20"
          label="电话"
          prepend-icon="phone"
          :rules="phoneRules"
            type="text">
        </v-text-field>


          <v-text-field variant="underlined" v-model="email" required
          :counter="20"
          label="电子邮箱"
           prepend-icon="email"
           :rules="emailRules"
            type="text">
        </v-text-field>

          <v-row class="mt-5">

            <v-btn class="ml-5" @click="handleRegister">提交</v-btn>

            <v-btn class="ml-5" @click="reset">复位</v-btn>

          </v-row>

        </v-form>

      </v-card-text>

    </v-card>

  </v-container>
</template>

<style scoped></style>
