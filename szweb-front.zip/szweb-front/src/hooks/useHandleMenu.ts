import {useAppStore} from "../store";

import router from "../router"



const appStore = useAppStore()

export const useHandleMenu=async (icon:string,url:string, type = '',isAdmin=false)=> {

    appStore.setUrl({icon,url, type})

    if(isAdmin){

        url=url+'List'

    }

    if (type) {

        url =url + '/' + type

    }

    url = '/' + url

    await router.push({path: url})

}