export const password = ref('')

import { ref } from "vue"

export const usernameRules = ref([

    (v: string) => !!v || '必须输入账号!',

    (v: string) => (v && v.length <= 20 && v.length >= 3) || '账号的长度为3到20个字符!',

])

export const passwordRules = ref([

    (v: string) => !!v || '必须输入密码!',

    (v: string) => (v && v.length <= 20 && v.length >= 8) || '密码的长度为8到20个字符!',

])

export const confirmPasswordRules = ref([

    (v: string) => !!v || '必须输入密码!',

    (v: string) => (v && v.length <= 20 && v.length >= 8) || '密码的长度为8到20个字符!',

    (v: string) => (v === password.value) || '两次密码输入不一致!',

])

export const nameRules = ref([

    (v: string) => !!v || '姓名不能为空!',

])

export const mobileRules = ref([

    (v: string) => !!v || '手机号不能为空!',

    (v: string) => (v && v.length <= 11 && v.length >= 11) || '请输入11位的手机号!',

])

export const emailRules = ref([

    (v: string) => !!v || '电子邮箱不能为空!',


    (v: string) => {
        const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        return pattern.test(v) || '无效的邮箱地址!'
    },
])

export const titleRules = ref([
    (v: string) => !!v || '必须输入标题!',
])

export const phoneRules = ref([
    (v:string) => (!!v && v.length != 13) || "无效的手机号",
])
